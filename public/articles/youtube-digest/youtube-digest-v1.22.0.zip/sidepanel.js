/**
 * SIDE PANEL LOGIC
 *
 * Handles the UI for YouTube Digest: video detection, transcript analysis,
 * rendering results, and export features.
 */

const DEBUG = false;
const debugLog = (...args) => {
  if (DEBUG) console.log(...args);
};

// ============================================================
// STATE
// ============================================================

let currentVideoId = null;
let currentVideoUrl = null;
let currentAnalysis = null;
let currentTranscript = null;
let currentTranscriptText = null; // Plain text (for display/export)
let currentTranscriptTimestamped = null; // With timestamps for AI analysis
let currentTranscriptLanguage = null;
let currentVideoTitle = "";
let currentChannelName = "";
let currentVideoDescription = "";
let currentVideoDuration = 0;
let isAnalysisLoading = false; // Track if analysis is in progress
let youtubeTabId = null; // Store the YouTube tab ID for reliable messaging
let errorAction = null;

// --- Translation state ---
// The public transcript control supports original subtitles plus Chinese and
// Japanese translation modes, with English- and Japanese-source bilingual views.
let currentTranscriptMode = "original";
let transcriptModeUserSelected = false;
let transcriptModeFromSettings = false;
let overviewLanguage = "zh";
let overviewOriginalAnalysis = null;
const overviewTranslations = new Map();
let transcriptOverlayMode = "side";
let overlayStyle = "normal";
let subtitleSyncOffset = 0;
let translationGeneration = 0; // Invalidates responses from older UI modes/videos.
let translationWorkCount = 0;
let transcriptScrollObserver = null;
// Stable keys include the video, source mode, language, and semantic segment ID.
let transcriptParagraphCache = new Map();
let nativeCaptionCues = [];
let nativeCaptionCuesLoaded = false;
let transcriptCalibrationPromise = null;
let nativeCaptionRetryTimer = null;
let nativeCaptionRetryCount = 0;
const CACHE_VERSION = 4;
const TRANSLATION_MESSAGE_TIMEOUT_MS = 130_000;

/**
 * Prevent a stopped service worker or dead message channel from leaving the
 * transcript queue stuck forever. The underlying Chrome message cannot be
 * cancelled, so settled guards deliberately ignore any late response.
 */
function sendTranslationMessage(message) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let timeoutId;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      callback(value);
    };

    timeoutId = setTimeout(() => {
      finish(
        reject,
        new Error(
          "Translation request timed out after 130 seconds. Please Retry.",
        ),
      );
    }, TRANSLATION_MESSAGE_TIMEOUT_MS);

    let messagePromise;
    try {
      messagePromise = chrome.runtime.sendMessage(message);
    } catch (error) {
      finish(reject, error);
      return;
    }

    Promise.resolve(messagePromise).then(
      (result) => finish(resolve, result),
      (error) => finish(reject, error),
    );
  });
}

// --- Auto-scroll state (follow video playback in transcript) ---
let autoScrollEnabled = true; // True = scroll transcript to follow video playback
let autoScrollInterval = null; // setInterval ID for polling video time
let lastAutoScrollTime = 0; // Timestamp of last programmatic scroll (ignores scroll events within 1s)
let playbackTrackingRunning = false;

// ============================================================
// TRANSCRIPT GROUPING
// ============================================================

const TRANSCRIPT_SEGMENT_LIMITS = Object.freeze({
  minChars: 60,
  idealChars: 180,
  maxChars: 320,
  maxSeconds: 20,
});
const TRANSCRIPT_PARAGRAPH_GAP_SECONDS = 1.5;

function normalizeCaptionText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .replace(
      /([\u3040-\u30ff\u3400-\u9fff])\s+([\u3040-\u30ff\u3400-\u9fff])/g,
      "$1$2",
    )
    .replace(/([，。、；：！？])\s+(?=[\u3040-\u30ff\u3400-\u9fff])/g, "$1")
    .replace(/\s+([,.;:!?，。、；：！？])/g, "$1")
    .trim();
}

/**
 * Splits a single oversized thought at the strongest nearby punctuation.
 * Word boundaries are the final safety valve for captions with no punctuation.
 */
function splitOversizedThought(text, maxChars) {
  const parts = [];
  let rest = normalizeCaptionText(text);

  while (rest.length > maxChars) {
    const windowText = rest.slice(0, maxChars + 1);
    const lowerBound = Math.floor(maxChars * 0.55);
    let cut = -1;

    for (const pattern of [/[;:；：]\s*/g, /[,，、]\s*/g, /\s/g]) {
      pattern.lastIndex = 0;
      let match;
      while ((match = pattern.exec(windowText))) {
        if (match.index >= lowerBound) cut = match.index + match[0].length;
      }
      if (cut > 0) break;
    }

    if (cut <= 0) cut = maxChars;
    parts.push(rest.slice(0, cut).trim());
    rest = rest.slice(cut).trim();
  }

  if (rest) parts.push(rest);
  return parts;
}

/**
 * Reconstructs complete sentences across raw caption boundaries. Each segment
 * keeps the timestamp of the first caption that contributed text. Character
 * and time limits prevent a malformed Supadata entry from becoming one giant
 * row while punctuation remains the preferred boundary.
 */
function groupTranscriptEntries(entries, limits = TRANSCRIPT_SEGMENT_LIMITS) {
  if (!Array.isArray(entries) || entries.length === 0) return [];

  const pieces = [];
  entries.forEach((entry, entryIndex) => {
    const text = normalizeCaptionText(entry?.text);
    if (!text) return;
    const start = Number.isFinite(Number(entry.start)) ? Number(entry.start) : 0;
    const duration = Math.max(0, Number(entry.duration) || 0);
    const sentenceParts =
      text.match(
        /[^.!?;:,。！？；：，、]+(?:[.!?;:,。！？；：，、]+["')\]”’）】」』]*|$)/g,
      ) || [text];
    let consumedChars = 0;

    sentenceParts.forEach((sentencePart) => {
      const cleanPart = normalizeCaptionText(sentencePart);
      if (!cleanPart) return;
      const oversizedParts = splitOversizedThought(cleanPart, limits.maxChars);
      oversizedParts.forEach((part, partIndex) => {
        const ratio = text.length ? Math.min(1, consumedChars / text.length) : 0;
        const nextRatio = text.length
          ? Math.min(1, (consumedChars + part.length) / text.length)
          : 1;
        const pieceStart = start + duration * ratio;
        const pieceEnd =
          pieceStart +
          Math.max(0.2, duration * (nextRatio - ratio));
        pieces.push({
          text: part,
          start: pieceStart,
          end: pieceEnd,
          duration,
          semanticEnd:
            /[.!?。！？]["')\]”’）】」』]*$/.test(part) ||
            oversizedParts.length > 1,
          clauseEnd: /[;:,；：，、]["')\]”’）】」』]*$/.test(part),
          sourceOrder: `${entryIndex}:${partIndex}`,
        });
        consumedChars += part.length + 1;
      });
    });
  });

  const grouped = [];
  let current = null;

  const flush = () => {
    if (!current || !current.text.trim()) return;
    const index = grouped.length;
    const text = normalizeCaptionText(current.text);
    grouped.push({
      id: `segment-${index}-${Math.round(current.start * 1000)}`,
      start: current.start,
      text,
      texts: [text],
      lines: current.lines,
    });
    current = null;
  };

  pieces.forEach((piece) => {
    if (!current) current = { start: piece.start, text: "", lines: [] };
    current.lines.push({ start: piece.start, end: piece.end, text: piece.text });
    current.text = normalizeCaptionText(`${current.text} ${piece.text}`);
    const elapsed = Math.max(0, piece.start - current.start);
    const comfortablySized = current.text.length >= limits.minChars;
    const reachedIdeal = current.text.length >= limits.idealChars;
    const atNaturalBoundary =
      piece.semanticEnd ||
      (piece.clauseEnd &&
        (reachedIdeal ||
          current.text.length >= limits.maxChars ||
          elapsed >= limits.maxSeconds));
    const reachedGuardrail =
      atNaturalBoundary &&
      (current.text.length >= limits.maxChars || elapsed >= limits.maxSeconds);
    const reachedHardGuardrail =
      current.text.length >= Math.round(limits.maxChars * 1.2) ||
      elapsed >= limits.maxSeconds + 5;

    if (
      (atNaturalBoundary && (comfortablySized || elapsed >= 8)) ||
      (atNaturalBoundary && reachedIdeal) ||
      reachedGuardrail ||
      reachedHardGuardrail
    ) {
      flush();
    }
  });
  flush();

  grouped.forEach((segment, index) => {
    const nextStart = grouped[index + 1]?.start ?? segment.start + 5;
    segment.lines.forEach((line, lineIndex) => {
      line.end =
        line.end ??
        (lineIndex + 1 < segment.lines.length
          ? segment.lines[lineIndex + 1].start
          : nextStart);
    });
  });

  return grouped;
}


function captionTextKey(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;|&amp;|&quot;|&lt;|&gt;/g, " ")
    .replace(/[^\p{L}\p{N}\u3040-\u30ff\u3400-\u9fff]/gu, "");
}

function captionTextBigrams(text) {
  const chars = Array.from(text);
  if (chars.length <= 1) return chars;
  const bigrams = [];
  for (let index = 0; index < chars.length - 1; index += 1) {
    bigrams.push(chars[index] + chars[index + 1]);
  }
  return bigrams;
}

function captionSimilarity(left, right) {
  const a = captionTextKey(left);
  const b = captionTextKey(right);
  if (!a || !b) return 0;
  const setA = new Set(captionTextBigrams(a));
  const setB = new Set(captionTextBigrams(b));
  if (!setA.size || !setB.size) return 0;
  let overlap = 0;
  setA.forEach((bigram) => {
    if (setB.has(bigram)) overlap += 1;
  });
  return (2 * overlap) / (setA.size + setB.size);
}

function alignTranscriptToNativeCues(entries, cues) {
  if (!Array.isArray(entries) || !entries.length) return entries;
  if (!Array.isArray(cues) || !cues.length) return entries;

  const native = cues
    .map((cue, index) => {
      const start = Number(cue.start) || 0;
      return {
        index,
        start,
        end: Math.max(start + 0.2, Number(cue.end) || start + 0.5),
        text: String(cue.text || ""),
      };
    })
    .sort((a, b) => a.start - b.start || a.end - b.end);

  const findCueStart = (time) => {
    let low = 0;
    let high = native.length;
    while (low < high) {
      const middle = (low + high) >> 1;
      if (native[middle].start < time - 20) low = middle + 1;
      else high = middle;
    }
    return low;
  };

  let lastNativeIndex = -1;
  return entries.map((entry) => {
    const originalStart = Number.isFinite(Number(entry.start))
      ? Number(entry.start)
      : 0;
    const originalEnd =
      originalStart + Math.max(0.2, Number(entry.duration) || 0);
    let best = null;
    let bestScore = 0;
    const startIndex = Math.max(0, findCueStart(originalStart) - 3);
    const endIndex = Math.min(native.length, startIndex + 24);

    for (let index = startIndex; index < endIndex; index += 1) {
      const candidate = native[index];
      if (candidate.start > originalEnd + 12 && best) break;
      const score = captionSimilarity(entry.text, candidate.text);
      if (score > bestScore) {
        bestScore = score;
        best = candidate;
        if (score >= 0.9) break;
      }
    }

    if (!best || bestScore < 0.45) {
      let fallback = null;
      let nearestDistance = Infinity;
      for (
        let index = Math.max(0, startIndex - 2);
        index < endIndex;
        index += 1
      ) {
        const candidate = native[index];
        const distance = Math.abs(candidate.start - originalStart);
        if (distance < nearestDistance) {
          nearestDistance = distance;
          fallback = candidate;
        }
      }
      if (!fallback && lastNativeIndex >= 0) {
        const orderCandidate = native[Math.min(lastNativeIndex, native.length - 1)];
        const orderDistance = Math.abs(orderCandidate.start - originalStart);
        if (orderDistance <= 12) {
          fallback = orderCandidate;
          nearestDistance = orderDistance;
        }
      }
      if (fallback && nearestDistance <= 12) {
        best = fallback;
        bestScore = Math.min(bestScore, 0.4);
      } else {
        best = null;
      }
    }

    if (best) lastNativeIndex = Math.max(lastNativeIndex, best.index);
    if (best) {
      return {
        ...entry,
        start: best.start,
        duration: Math.max(0.2, best.end - best.start),
        nativeCueIndex: best.index,
      };
    }

    return {
      ...entry,
      start: originalStart,
      duration: Math.max(0.2, originalEnd - originalStart),
    };
  });
}

async function loadNativeCaptionCues() {
  if (nativeCaptionCuesLoaded) return nativeCaptionCues;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    let cues = [];
    if (youtubeTabId) {
      try {
        const response = await chrome.tabs.sendMessage(youtubeTabId, {
          action: "getNativeCaptionCues",
        });
        cues = response?.cues || [];
      } catch (_error) {
        // Fall through to the background relay.
      }
    }
    if (!cues.length) {
      try {
        const result = await chrome.runtime.sendMessage({
          action: "relayToContent",
          payload: { action: "getNativeCaptionCues" },
        });
        cues = result?.response?.cues || [];
      } catch (_error) {
        // The YouTube tab may not be ready yet.
      }
    }
    if (cues.length) {
      nativeCaptionCues = cues;
      nativeCaptionCuesLoaded = true;
      return cues;
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  return [];
}

async function calibrateTranscriptWithNativeCues() {
  if (transcriptCalibrationPromise) return transcriptCalibrationPromise;
  transcriptCalibrationPromise = (async () => {
    try {
      const cues = await loadNativeCaptionCues();
      if (Array.isArray(currentTranscript) && cues.length) {
        const aligned = alignTranscriptToNativeCues(currentTranscript, cues);
        if (aligned.length === currentTranscript.length) {
          currentTranscript = aligned;
        }
      } else if (
        !cues.length &&
        !nativeCaptionRetryTimer &&
        nativeCaptionRetryCount < 3 &&
        currentVideoId
      ) {
        nativeCaptionRetryTimer = setTimeout(() => {
          nativeCaptionRetryTimer = null;
          nativeCaptionRetryCount += 1;
          calibrateTranscriptWithNativeCues().then(() => {
            if (nativeCaptionCues.length) {
              if (currentTranscriptMode === "original") {
                renderTranscript();
              } else {
                translateTranscript();
              }
              syncTranscriptOverlay();
            }
          });
        }, 1500);
      }
    } finally {
      transcriptCalibrationPromise = null;
    }
  })();
  return transcriptCalibrationPromise;
}


function nativeCueToTranscriptEntry(cue) {
  const start = Number(cue?.start) || 0;
  const end = Math.max(start + 0.2, Number(cue?.end) || start + 0.5);
  const text = String(cue?.text || "")
    .replace(/<[^>]*>/g, "")
    .replace(/>> ?/g, "")
    .replace(/\s+/g, " ")
    .trim();
  return {
    text,
    start,
    duration: Math.max(0.2, end - start),
    language: null,
  };
}

function detectFallbackTranscriptLanguage(text) {
  const sample = String(text || "").slice(0, 5000);
  const japaneseKana = (sample.match(/[\u3040-\u30ff]/g) || []).length;
  if (japaneseKana > 0) return "ja";
  const latinLetters = (sample.match(/[A-Za-z]/g) || []).length;
  if (latinLetters > 40) return "en";
  const hanCharacters = (sample.match(/[\u3400-\u9fff]/g) || []).length;
  if (hanCharacters > 20) return "zh";
  return null;
}

async function fallbackToNativeCaptionCues(videoId) {
  const cues = await loadNativeCaptionCues();
  if (!Array.isArray(cues) || !cues.length) return false;
  const transcript = cues
    .map(nativeCueToTranscriptEntry)
    .filter((entry) => entry.text);
  if (!transcript.length) return false;

  currentTranscript = transcript;
  currentTranscriptText = transcript.map((entry) => entry.text).join(" ");
  currentTranscriptTimestamped = transcript
    .map((entry) => {
      const minutes = Math.floor(entry.start / 60);
      const seconds = String(Math.floor(entry.start % 60)).padStart(2, "0");
      return `[${minutes}:${seconds}] ${entry.text}`;
    })
    .join("\n");
  currentTranscriptLanguage =
    detectFallbackTranscriptLanguage(currentTranscriptText);
  applyDetectedTranscriptLanguage(currentTranscriptLanguage);
  isAnalysisLoading = false;

  renderTranscript();
  showState("results");
  document.getElementById("tabsNav").style.display = "flex";
  loadNotes(videoId);
  setupExplainFeature();
  if (currentTranscriptMode !== "original") translateTranscript();
  await saveToCache(videoId);
  return true;
}

// ============================================================
// INITIALIZATION
// ============================================================

document.addEventListener("DOMContentLoaded", async () => {
  setupEventListeners();
  await loadTranscriptModePreference();
  await loadOverlayModePreference();
  await loadOverlayStylePreference();
  await evictOldCacheEntries(20);

  const configStatus = await chrome.runtime.sendMessage({
    action: "checkConfig",
  });

  if (!configStatus.hasSupadataKey || !configStatus.hasAiKey) {
    showConfigError(configStatus);
    return;
  }

  await checkCurrentTab();
});

// Listen for messages from the Digest button on YouTube page
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "overlayModeChanged") {
    transcriptOverlayMode =
      message.mode === "below" || message.mode === "above"
        ? message.mode
        : message.mode === "off"
          ? "off"
          : "side";
    const select = document.getElementById("overlayModeSelect");
    if (select) select.value = transcriptOverlayMode;
    syncTranscriptOverlay();
    sendResponse({ success: true });
  }
  if (message.action === "overlayStyleChanged") {
    loadOverlayStylePreference().then(syncTranscriptOverlay);
    sendResponse({ success: true });
  }
  if (message.action === "nativeCueChanged") {
    if (typeof message.currentTime === "number") {
      if (message.text) {
        highlightActiveEntryByText(
          message.currentTime + subtitleSyncOffset,
          message.text,
        );
      } else {
        highlightActiveEntry(message.currentTime + subtitleSyncOffset);
      }
    }
    sendResponse({ success: true });
  }
  if (message.action === "startDigestFromButton") {
    // Load the digest for the current video. Served from cache when we've
    // seen this video before (no API calls); fetched fresh otherwise.
    // (This used to force-clear the cache on every click, which silently
    // burned a transcript credit + analysis tokens per click.)
    checkCurrentTab();
    sendResponse({ success: true });
  }
  if (message.action === "transcriptProgress") {
    // Background is telling us the transcript fetch status changed
    updateLoading(message.title, message.subtitle);
    sendResponse({ success: true });
  }
  if (message.action === "noteSaved") {
    // Refresh notes list when a new note is saved
    const filterAll = document
      .getElementById("notesFilterAll")
      ?.classList.contains("active");
    loadNotes(filterAll ? null : currentVideoId);
    sendResponse({ success: true });
  }
  return false;
});

// ============================================================
// FOLLOW THE ACTIVE TAB
// ============================================================
// The panel watches which tab is in front of it and reacts:
//   - Front tab is NOT YouTube  -> the panel closes itself (window.close()).
//     We do this OURSELVES rather than relying only on the background
//     script's per-tab enable/disable, because Chrome doesn't reliably
//     apply per-tab panel state to tabs spawned in unusual ways (e.g. a
//     link opened from another app) — which let the panel linger on
//     non-YouTube pages.
//   - Front tab IS YouTube but on a different video -> refresh the digest.
//     YouTube is a single-page app (clicking a video swaps content without
//     a reload), so we track URL changes; startDigest() caches per video,
//     making re-checks instant and free for already-digested videos.
//
// Everything is scoped to the window this panel lives in: tab switches in
// OTHER browser windows must not close this panel or hijack its content.

let navigationRefreshTimer = null;
let panelWindowId = null;
chrome.windows.getCurrent().then((w) => {
  panelWindowId = w.id;
});

function scheduleDigestRefresh() {
  // Small delay lets YouTube finish rendering the new video's title and
  // description before we read them. Also collapses rapid-fire URL events
  // into a single refresh.
  clearTimeout(navigationRefreshTimer);
  navigationRefreshTimer = setTimeout(() => {
    checkCurrentTab();
  }, 600);
}

function panelIsShowingResults() {
  const results = document.getElementById("resultsState");
  return results && results.style.display !== "none";
}

/**
 * Reacts to the URL now in front of the panel: close on non-YouTube,
 * refresh the digest when the video changed.
 */
function handleFrontTabUrl(url) {
  if (!(url || "").startsWith("https://www.youtube.com")) {
    // Panel is a YouTube-only tool — remove itself from non-YouTube tabs.
    window.close();
    return;
  }

  const newVideoId = extractVideoId(url);
  // Refresh when the video changed, or when we're not currently showing
  // results (e.g. user went home, then clicked back into the same video).
  if (newVideoId !== currentVideoId || !panelIsShowingResults()) {
    scheduleDigestRefresh();
  }
}

// Fires when a tab's URL changes — including YouTube's no-reload navigation.
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo.url || !tab.active) return;
  if (panelWindowId !== null && tab.windowId !== panelWindowId) return;
  handleFrontTabUrl(changeInfo.url);
});

// Fires when a different tab comes to the front — switching tabs, or a new
// tab being opened (including ones opened by clicking links in other apps).
chrome.tabs.onActivated.addListener(async ({ tabId, windowId }) => {
  if (panelWindowId !== null && windowId !== panelWindowId) return;
  try {
    const tab = await chrome.tabs.get(tabId);
    // Brand-new tabs may not have committed their URL yet — fall back to
    // the pending one so we judge where the tab is actually going.
    handleFrontTabUrl(tab.url || tab.pendingUrl || "");
  } catch (e) {
    // Tab closed before we could read it — nothing to do.
  }
});

function setupEventListeners() {
  // Tab switching
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => switchTab(tab.dataset.tab));
  });

  // Error retry
  document.getElementById("errorBtn").addEventListener("click", () => {
    if (errorAction) {
      errorAction();
      return;
    }
    if (currentVideoId) {
      startDigest(currentVideoId, currentVideoUrl);
    }
  });

  document.getElementById("settingsBtn")?.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "openOptions" });
  });
  document
    .getElementById("overlayModeSelect")
    ?.addEventListener("change", async (event) => {
      transcriptOverlayMode = event.target.value;
      await chrome.storage.local.set({
        ytd_overlay_mode: transcriptOverlayMode,
      });
      await syncTranscriptOverlay();
    });

  // Transcript actions
  document
    .getElementById("copyTranscriptBtn")
    ?.addEventListener("click", copyTranscript);
  document
    .getElementById("exportTranscriptBtn")
    ?.addEventListener("click", exportTranscript);
  document
    .getElementById("transcriptModeSelect")
    ?.addEventListener("change", async (event) => {
      const mode = event.target.value;
      transcriptModeUserSelected = true;
      await persistTranscriptMode(mode);
      handleTranscriptModeChange(mode);
    });
  document
    .getElementById("overviewLanguageSelect")
    ?.addEventListener("change", async (event) => {
      overviewLanguage = event.target.value;
      await refreshOverviewLanguage();
    });
  document
    .getElementById("transcriptNavFloatingBtn")
    ?.addEventListener("click", handleTranscriptNavClick);

  document
    .getElementById("exportAllDocsBtn")
    ?.addEventListener("click", async (event) => {
      const button = event.target;
      button.textContent = "Copying…";
      try {
        await exportAllNotesToDocs();
        button.textContent = "✓ Docs";
      } catch (error) {
        button.textContent = "Error";
        console.error("Export all notes to Google Docs failed:", error);
      }
      setTimeout(() => {
        button.textContent = "Docs All";
      }, 2000);
    });
  document
    .getElementById("exportAllShimoBtn")
    ?.addEventListener("click", async (event) => {
      const button = event.target;
      button.textContent = "Copying…";
      try {
        await exportAllNotesToShimo();
        button.textContent = "✓ 石墨";
      } catch (error) {
        button.textContent = "Error";
        console.error("Export all notes to Shimo failed:", error);
      }
      setTimeout(() => {
        button.textContent = "石墨 All";
      }, 2000);
    });

  // Follow playback button — re-enables auto-scroll after user scrolled away
  document
    .getElementById("followPlaybackBtn")
    ?.addEventListener("click", () => {
      autoScrollEnabled = true;
      document.getElementById("followPlaybackBtn").style.display = "none";
      // Jump straight back to the line currently being spoken. We scroll
      // directly (not via playbackTrackingTick) because the tick skips
      // entries that are already highlighted — and the current line almost
      // always IS highlighted, which made this button appear to do nothing.
      if (!scrollToActiveEntry()) {
        playbackTrackingTick(); // No highlight yet — let a tick establish one
      }
    });

  // Notes filter buttons
  document.getElementById("notesFilterThis")?.addEventListener("click", () => {
    setNotesFilter(false);
    loadNotes(currentVideoId);
  });
  document.getElementById("notesFilterAll")?.addEventListener("click", () => {
    setNotesFilter(true);
    loadNotes(null); // Load all notes
  });
}

function setNotesFilter(showAll) {
  const thisVideoButton = document.getElementById("notesFilterThis");
  const allNotesButton = document.getElementById("notesFilterAll");
  thisVideoButton?.classList.toggle("active", !showAll);
  thisVideoButton?.setAttribute("aria-pressed", String(!showAll));
  allNotesButton?.classList.toggle("active", showAll);
  allNotesButton?.setAttribute("aria-pressed", String(showAll));
}

// ============================================================
// VIDEO DETECTION
// ============================================================

async function checkCurrentTab() {
  try {
    // Try multiple strategies to find the YouTube tab
    let tab = null;

    // Strategy 1: Active tab in last focused window
    let tabs = await chrome.tabs.query({
      active: true,
      lastFocusedWindow: true,
    });
    if (tabs[0]?.url?.includes("youtube.com")) {
      tab = tabs[0];
    }

    // Strategy 2: Any active YouTube tab
    if (!tab) {
      tabs = await chrome.tabs.query({
        url: "https://www.youtube.com/*",
        active: true,
      });
      if (tabs[0]) tab = tabs[0];
    }

    // Strategy 3: Any YouTube tab (last resort)
    if (!tab) {
      tabs = await chrome.tabs.query({ url: "https://www.youtube.com/*" });
      if (tabs[0]) tab = tabs[0];
    }

    debugLog("[YouTube Digest Panel] Found tab:", tab?.id, tab?.url);

    if (!tab?.url) {
      showState("welcome");
      return;
    }

    // Store the tab ID for reliable messaging later
    youtubeTabId = tab.id;

    const videoId = extractVideoId(tab.url);

    if (videoId) {
      currentVideoUrl = tab.url;

      try {
        // Route through background script for reliable message passing
        const result = await chrome.runtime.sendMessage({
          action: "relayToContent",
          payload: { action: "getVideoInfo" },
        });
        debugLog("[YouTube Digest Panel] getVideoInfo result:", result);
        if (result.success && result.response) {
          currentVideoTitle = result.response.title || "";
          currentChannelName = result.response.channelName || "";
          currentVideoDescription = result.response.description || "";
          currentVideoDuration = result.response.duration || 0;
        }
      } catch (e) {
        console.error("[YouTube Digest Panel] getVideoInfo error:", e);
        currentVideoTitle = "";
        currentChannelName = "";
        currentVideoDescription = "";
        currentVideoDuration = 0;
      }

      startDigest(videoId, tab.url);
    } else {
      showState("welcome");
    }
  } catch (error) {
    console.error("Tab check error:", error);
    showState("welcome");
  }
}

function extractVideoId(url) {
  try {
    const urlObj = new URL(url);

    if (
      urlObj.hostname.includes("youtube.com") &&
      urlObj.searchParams.has("v")
    ) {
      return urlObj.searchParams.get("v");
    }

    if (urlObj.hostname === "youtu.be") {
      return urlObj.pathname.slice(1);
    }

    if (urlObj.pathname.startsWith("/embed/")) {
      return urlObj.pathname.split("/")[2];
    }

    return null;
  } catch {
    return null;
  }
}

// ============================================================
// DIGEST PIPELINE
// ============================================================

async function startDigest(videoId, videoUrl) {
  // Check if we already have this video loaded in memory
  if (videoId === currentVideoId && currentAnalysis) {
    showState("results");
    return;
  }

  // Every video change invalidates observer work and in-flight translations.
  if (videoId !== currentVideoId) {
    translationGeneration += 1;
    nativeCaptionCues = [];
    nativeCaptionCuesLoaded = false;
    transcriptCalibrationPromise = null;
    if (nativeCaptionRetryTimer) clearTimeout(nativeCaptionRetryTimer);
    nativeCaptionRetryTimer = null;
    nativeCaptionRetryCount = 0;
    transcriptModeUserSelected = transcriptModeFromSettings;
    overviewOriginalAnalysis = null;
    overviewTranslations.clear();
    if (transcriptScrollObserver) transcriptScrollObserver.disconnect();
    transcriptScrollObserver = null;
  }

  // Check cache for this video
  const cached = await loadFromCache(videoId);
  if (cached) {
    debugLog("Loading from cache:", videoId);
    currentVideoId = videoId;
    currentVideoUrl = videoUrl;
    currentAnalysis = cached.analysis || null;
    currentTranscript = cached.transcript;
    currentTranscriptText = cached.transcriptText;
    currentTranscriptTimestamped = cached.transcriptTimestamped;
    currentTranscriptLanguage = cached.transcriptLanguage || null;
    await calibrateTranscriptWithNativeCues();
    applyDetectedTranscriptLanguage(currentTranscriptLanguage);
    isAnalysisLoading = false;

    // Restore semantic-segment translations from persistent storage.
    if (cached.paragraphCache) {
      for (const [key, value] of Object.entries(cached.paragraphCache)) {
        transcriptParagraphCache.set(key, value);
      }
    }

    if (currentVideoTitle || currentChannelName) {
      const videoInfo = document.getElementById("videoInfo");
      document.getElementById("videoTitle").textContent = currentVideoTitle;
      document.getElementById("videoChannel").textContent = currentChannelName;
      videoInfo.style.display = "block";
    }

    // Always render transcript first
    renderTranscript();

    // Render analysis if we have it cached
    if (currentAnalysis) {
      renderAnalysisResults(currentAnalysis);
      highlightMomentsOnPage(currentAnalysis.keyMoments);
    }

    showState("results");
    document.getElementById("tabsNav").style.display = "flex";

    // Load notes for this video
    loadNotes(videoId);

    // Setup explain feature
    setupExplainFeature();
    if (currentTranscriptMode !== "original") translateTranscript();
    return;
  }

  currentVideoId = videoId;
  currentVideoUrl = videoUrl;
  currentAnalysis = null;
  currentTranscript = null;
  currentTranscriptText = null;
  currentTranscriptTimestamped = null;
  currentTranscriptLanguage = null;
  isAnalysisLoading = false;

  if (currentVideoTitle || currentChannelName) {
    const videoInfo = document.getElementById("videoInfo");
    document.getElementById("videoTitle").textContent = currentVideoTitle;
    document.getElementById("videoChannel").textContent = currentChannelName;
    videoInfo.style.display = "block";
  }

  showState("loading");
  updateLoading("Fetching transcript", "");

  const transcriptResult = await chrome.runtime.sendMessage({
    action: "fetchTranscript",
    videoId: videoId,
    tabId: youtubeTabId || undefined,
  });

  if (!transcriptResult.success) {
    if (await fallbackToNativeCaptionCues(videoId)) return;
    if (transcriptResult.error === "NO_SUPADATA_KEY") {
      showError(
        "API key missing",
        "Add your Supadata API key in YouTube Digest Settings.",
      );
      return;
    }
    showError(
      "No transcript found",
      transcriptResult.message || transcriptResult.error,
    );
    return;
  }

  currentTranscript = transcriptResult.transcript;
  await calibrateTranscriptWithNativeCues();
  currentTranscriptText = transcriptResult.transcriptText;
  currentTranscriptTimestamped = transcriptResult.transcriptTextTimestamped;
  currentTranscriptLanguage = transcriptResult.language || null;
  applyDetectedTranscriptLanguage(currentTranscriptLanguage);

  // Render transcript immediately (no LLM needed)
  renderTranscript();
  showState("results");
  document.getElementById("tabsNav").style.display = "flex";

  // Load notes for this video
  loadNotes(videoId);

  // Setup explain feature for text selection
  setupExplainFeature();
  if (currentTranscriptMode !== "original") translateTranscript();

  // Save transcript to cache (without analysis)
  await saveToCache(videoId);

  // DON'T run LLM analysis automatically - wait for user to click Overview tab
  // This saves tokens when user just wants to see the transcript
}

// ============================================================
// RENDERING
// ============================================================

/**
 * Renders the analysis results into the Overview tab.
 * Shows chapters and key quotes only.
 */
function renderAnalysisResults(analysis) {
  // Chapters
  const chapterList = document.getElementById("chapterList");
  chapterList.innerHTML = "";
  (analysis.chapters || []).forEach((chapter) => {
    const li = document.createElement("li");
    li.className = "chapter-item";
    li.dataset.seconds = chapter.timestampSeconds;
    li.innerHTML = `
      <span class="chapter-timestamp">${escapeHtml(chapter.timestamp)}</span>
      <div class="chapter-content">
        <span class="chapter-title">${escapeHtml(chapter.title)}</span>
        <span class="chapter-summary">${escapeHtml(chapter.summary || "")}</span>
      </div>
    `;
    li.addEventListener("click", () => {
      debugLog(
        "[YouTube Digest Panel] Chapter clicked:",
        chapter.timestamp,
        chapter.timestampSeconds,
      );
      seekTo(chapter.timestampSeconds);
    });
    chapterList.appendChild(li);
  });

  const summaryContainer = document.getElementById("analysisSummary");
  if (summaryContainer) {
    renderAnalysisSummary(summaryContainer, analysis);
  }

  // Quotes - sort by timestamp (chronological order)
  const quotesList = document.getElementById("quotesList");
  quotesList.innerHTML = "";
  const sortedQuotes = [...(analysis.keyQuotes || [])].sort(
    (a, b) => (a.timestampSeconds || 0) - (b.timestampSeconds || 0),
  );
  sortedQuotes.forEach((quote) => {
    const div = document.createElement("div");
    div.className = "quote-item";
    div.dataset.seconds = quote.timestampSeconds;
    div.innerHTML = `
      <div class="quote-text">${escapeHtml(quote.quote)}</div>
      <div class="quote-meta">
        <span class="quote-timestamp">${escapeHtml(quote.timestamp)}</span>
        <div class="quote-actions">
          <button class="quote-save-note-btn" title="Save this quote as a note">📝 Note</button>
          <button class="quote-copy-btn" title="Copy this quote">⧉ Copy</button>
        </div>
      </div>
    `;
    div.addEventListener("click", () => {
      debugLog(
        "[YouTube Digest Panel] Quote clicked:",
        quote.timestamp,
        quote.timestampSeconds,
      );
      seekTo(quote.timestampSeconds);
    });

    const quoteCopyBtn = div.querySelector(".quote-copy-btn");
    quoteCopyBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      try {
        await navigator.clipboard.writeText(quote.quote);
        quoteCopyBtn.textContent = "✓ Copied";
        setTimeout(() => {
          quoteCopyBtn.textContent = "⧉ Copy";
        }, 1500);
      } catch (err) {
        console.error("Copy failed:", err);
      }
    });

    const quoteSaveNoteBtn = div.querySelector(".quote-save-note-btn");
    quoteSaveNoteBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      await saveQuoteAsNote(quote, quoteSaveNoteBtn);
    });

    quotesList.appendChild(div);
  });
}

function renderAnalysisSummary(container, analysis) {
  const summary = String(analysis.summary || "").trim();
  const corePoints = Array.isArray(analysis.corePoints)
    ? analysis.corePoints
    : [];
  const actionSteps = Array.isArray(analysis.actionSteps)
    ? analysis.actionSteps
    : [];
  const terms = Array.isArray(analysis.terms) ? analysis.terms : [];

  if (!summary && !corePoints.length && !actionSteps.length && !terms.length) {
    container.innerHTML = `<div class="placeholder-text">Summary will appear here</div>`;
    return;
  }

  let html = "";
  if (summary) {
    html += `<div class="analysis-summary-text">${escapeHtml(summary)}</div>`;
  }
  if (corePoints.length) {
    html += `<h3 class="analysis-subheading">Core Points</h3><ul class="analysis-list">${corePoints
      .map((point) => `<li>${escapeHtml(point)}</li>`)
      .join("")}</ul>`;
  }
  if (actionSteps.length) {
    html += `<h3 class="analysis-subheading">Next Actions</h3><ol class="analysis-list">${actionSteps
      .map((step) => `<li>${escapeHtml(step)}</li>`)
      .join("")}</ol>`;
  }
  if (terms.length) {
    html += `<h3 class="analysis-subheading">Terms Explained Simply</h3>`;
    html += `<div class="term-list">${terms
      .map(
        (item) =>
          `<div class="term-item"><strong>${escapeHtml(item.term)}</strong><p>${escapeHtml(item.explanation)}</p></div>`,
      )
      .join("")}</div>`;
  }
  container.innerHTML = html;
}

async function refreshOverviewLanguage() {
  if (isAnalysisLoading) return;
  if (!currentAnalysis) {
    triggerAnalysis();
    return;
  }

  if (overviewTranslations.has(overviewLanguage)) {
    currentAnalysis = overviewTranslations.get(overviewLanguage);
    renderAnalysisResults(currentAnalysis);
    return;
  }

  isAnalysisLoading = true;
  const summaryContainer = document.getElementById("analysisSummary");
  if (summaryContainer) {
    summaryContainer.innerHTML =
      '<div class="placeholder-text">Translating summary...</div>';
  }

  try {
    const result = await chrome.runtime.sendMessage({
      action: "translateOverviewContent",
      content: currentAnalysis,
      targetLanguage: overviewLanguage,
    });
    if (result.success) {
      currentAnalysis = result.analysis;
      overviewTranslations.set(overviewLanguage, currentAnalysis);
      renderAnalysisResults(currentAnalysis);
      await saveToCache(currentVideoId);
    }
  } catch (error) {
    console.error("[YouTube Digest] Overview translation failed:", error);
  } finally {
    isAnalysisLoading = false;
  }
}

/**
 * Saves a key quote as a timestamped note.
 */
async function saveQuoteAsNote(quote, btn) {
  if (!currentVideoId) return;

  const originalText = btn.textContent;
  btn.textContent = "Saving...";
  btn.disabled = true;

  try {
    const result = await chrome.runtime.sendMessage({
      action: "saveNote",
      videoId: currentVideoId,
      timestamp: quote.timestampSeconds,
      videoTitle: currentVideoTitle,
      channelName: currentChannelName,
    });

    if (result.success) {
      btn.textContent = "✓ Saved";
      setTimeout(() => {
        btn.textContent = originalText;
        btn.disabled = false;
      }, 1500);
      // Refresh notes list if on Notes tab
      loadNotes(currentVideoId);
    } else {
      console.error("[YouTube Digest] Save quote as note failed:", result.error);
      btn.textContent = "Error";
      setTimeout(() => {
        btn.textContent = originalText;
        btn.disabled = false;
      }, 1500);
    }
  } catch (error) {
    console.error("[YouTube Digest] Save quote as note error:", error);
    btn.textContent = "Error";
    setTimeout(() => {
      btn.textContent = originalText;
      btn.disabled = false;
    }, 1500);
  }
}

/**
 * Legacy function for backwards compatibility with cached data.
 * Renders both transcript and analysis.
 */
function renderResults(analysis) {
  renderAnalysisResults(analysis);

  renderTranscript();

  document.getElementById("tabsNav").style.display = "flex";

  // Setup explain feature for text selection
  setupExplainFeature();
}

/**
 * Returns true while the user has a range of text selected.
 * Transcript row clicks must not seek in that state: the click emitted after
 * selection mouseup belongs to the selection/explain interaction, not playback.
 */
function hasNonCollapsedTextSelection() {
  const selection = window.getSelection();
  return Boolean(
    selection && selection.rangeCount > 0 && !selection.isCollapsed,
  );
}

/**
 * Preserves normal row-click seeking while keeping text selection inert.
 */
function seekFromTranscriptEntryClick(event, seconds) {
  if (hasNonCollapsedTextSelection()) {
    event.preventDefault();
    event.stopPropagation();
    return;
  }

  seekTo(seconds);
}

function renderTranscript() {
  if (!currentTranscript) return;

  const transcriptList = document.getElementById("transcriptList");
  transcriptList.innerHTML = "";

  // Show a small badge indicating the transcript came from the video's
  // existing subtitles. (We no longer AI-transcribe audio, so subtitles
  // are the only source.)
  const existingBadge = document.getElementById("transcriptSourceBadge");
  if (existingBadge) existingBadge.remove();

  const badge = document.createElement("div");
  badge.id = "transcriptSourceBadge";
  badge.className = "transcript-source-badge";
  badge.innerHTML = `<span class="source-dot source-dot--subs"></span> From video subtitles · ${escapeHtml(getOriginalTranscriptLabel())}`;
  transcriptList.parentElement.insertBefore(badge, transcriptList);

  // Group entries using smart sentence-boundary + time-guardrail logic
  const grouped = groupTranscriptEntries(currentTranscript);

  grouped.forEach((group, index) => {
    const div = document.createElement("div");
    const previousStart = index > 0 ? grouped[index - 1].start : null;
    const paragraphBreak = shouldStartTranscriptParagraph(
      previousStart,
      group.start,
    );
    div.className = `transcript-entry${paragraphBreak ? " paragraph-break" : ""}`;
    div.dataset.seconds = group.start;

    const minutes = Math.floor(group.start / 60);
    const seconds = Math.floor(group.start % 60);
    const timestamp = `${minutes}:${String(seconds).padStart(2, "0")}`;

    div.innerHTML = `
      <span class="transcript-time">${timestamp}</span>
      <span class="transcript-text">${renderTranscriptLines(group.lines) || renderSubtitleInlineMarkup(group.text)}</span>
    `;

    div.addEventListener("click", (event) =>
      seekFromTranscriptEntryClick(event, group.start),
    );
    div.querySelector(".transcript-time").addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      seekTo(group.start);
    });
    transcriptList.appendChild(div);
  });

  // Start tracking video playback for auto-scroll
  startPlaybackTracking();
  updateTranscriptNavVisibility();
  syncTranscriptOverlay();
}

function copyTranscript() {
  copyToClipboardWithFeedback(
    getCurrentTranscriptViewText(),
    "copyTranscriptBtn",
  );
}

function exportTranscript() {
  const transcriptContent = getCurrentTranscriptViewText();
  const videoUrl = `https://youtube.com/watch?v=${currentVideoId}`;

  let exportText = "";
  exportText += `TRANSCRIPT\n`;
  exportText += `${"=".repeat(60)}\n\n`;
  exportText += `Title: ${currentVideoTitle || "Unknown"}\n`;
  exportText += `Channel: ${currentChannelName || "Unknown"}\n`;
  exportText += `URL: ${videoUrl}\n`;
  exportText += `\n${"—".repeat(60)}\n\n`;

  if (currentVideoDescription) {
    exportText += `DESCRIPTION:\n${currentVideoDescription}\n`;
    exportText += `\n${"—".repeat(60)}\n\n`;
  }

  exportText += `TRANSCRIPT:\n\n${transcriptContent}\n`;
  exportText += `\n${"—".repeat(60)}\n`;
  exportText += `Exported by YouTube Digest\n`;

  const filename = `${sanitizeFilename(currentVideoTitle)}-transcript.txt`;
  downloadTextFile(exportText, filename);
}

function getCurrentTranscriptViewText() {
  const rows = [
    ...document.querySelectorAll("#transcriptList .transcript-entry"),
  ];
  if (!rows.length) return currentTranscriptText || "";

  return rows
    .map((row) => {
      const time =
        row.querySelector(".transcript-time")?.textContent?.trim() || "";
      const originalEl = row.querySelector(
        ".transcript-original, .transcript-text",
      );
      const translationEl = row.querySelector(".transcript-translation");
      const originalLines = [
        ...row.querySelectorAll(".transcript-line"),
      ].map((line) => line.textContent?.trim() || "");
      const original =
        originalLines.filter(Boolean).join("\n") ||
        originalEl?.textContent?.trim() ||
        "";
      let translation = translationEl?.textContent?.trim() || "";
      if (
        /Waiting for translation|Retrying…|Translation unavailable|Retry/.test(
          translation,
        )
      ) {
        translation = "";
      }

      if (currentTranscriptMode === "original") {
        return `[${time}] ${original}`;
      }
      if (
        currentTranscriptMode === "bilingual-en" ||
        currentTranscriptMode === "bilingual-ja"
      ) {
        return `[${time}] ${original}\n${translation}`;
      }
      return `[${time}] ${translation || original}`;
    })
    .join("\n");
}

function getTranscriptOverlayLines() {
  const rows = [
    ...document.querySelectorAll("#transcriptList .transcript-entry"),
  ];
  const isBilingual =
    currentTranscriptMode === "bilingual-en" ||
    currentTranscriptMode === "bilingual-ja";
  const isTranslatedOnly =
    currentTranscriptMode === "zh" || currentTranscriptMode === "ja";

  return rows.map((row, index) => {
    const start = Number(row.dataset.seconds) || 0;
    const next = Number(rows[index + 1]?.dataset.seconds) || start + 5;
    const originalLines = [
      ...row.querySelectorAll(".transcript-line"),
    ].map((line) => {
      const start = Number(line.dataset.start) || 0;
      return {
        text: line.textContent?.trim() || "",
        start,
        end: Math.max(start + 0.2, Number(line.dataset.end) || start + 0.5),
      };
    });
    const original =
      originalLines
        .map((line) => line.text)
        .filter(Boolean)
        .join(" ") ||
      row.querySelector(".transcript-text")?.textContent?.trim() ||
      "";
    const translation =
      row.querySelector(".transcript-translation")?.textContent?.trim() || "";

    return {
      start,
      end: Math.max(start + 0.5, next),
      text: isTranslatedOnly ? translation || original : original,
      translation: isBilingual ? translation : "",
      original,
      lines: originalLines.length
        ? originalLines
        : [{ text: original, start, end: Math.max(start + 0.5, next) }],
    };
  }).filter((line) => line.text || line.translation);
}

async function syncTranscriptOverlay() {
  if (!youtubeTabId) return;
  const payload = {
    action: "setTranscriptOverlay",
    mode: transcriptOverlayMode,
    style: overlayStyle,
    syncOffset: subtitleSyncOffset,
    lines: getTranscriptOverlayLines(),
  };
  try {
    await chrome.tabs.sendMessage(youtubeTabId, payload);
  } catch (_error) {
    try {
      await chrome.runtime.sendMessage({
        action: "relayToContent",
        payload,
      });
    } catch (relayError) {
      debugLog("[YouTube Digest Panel] Overlay sync failed:", relayError.message);
    }
  }
}

function scrollTranscriptToTop() {
  autoScrollEnabled = false;
  document.getElementById("followPlaybackBtn").style.display = "block";
  const container = document.getElementById("contentArea");
  if (container) container.scrollTop = 0;
  updateTranscriptNavVisibility();
}

function scrollTranscriptToBottom() {
  autoScrollEnabled = false;
  document.getElementById("followPlaybackBtn").style.display = "block";
  const container = document.getElementById("contentArea");
  if (container) container.scrollTop = container.scrollHeight;
  updateTranscriptNavVisibility();
}

function scrollTranscriptToCurrent() {
  autoScrollEnabled = true;
  document.getElementById("followPlaybackBtn").style.display = "none";
  if (!scrollToActiveEntry()) {
    playbackTrackingTick();
  }
}

function updateTranscriptNavVisibility() {
  const nav = document.getElementById("transcriptNavButtons");
  if (!nav) return;
  if (!currentTranscript) {
    nav.style.display = "none";
    return;
  }

  const container = document.getElementById("contentArea");
  const button = document.getElementById("transcriptNavFloatingBtn");
  const atTop = !container || container.scrollTop < 40;
  nav.style.display = "flex";
  if (button) {
    if (atTop) {
      button.textContent = "直达底部";
      button.dataset.action = "bottom";
      button.title = "直达底部";
    } else {
      button.textContent = "回到顶部";
      button.dataset.action = "top";
      button.title = "回到顶部";
    }
  }
}

function handleTranscriptNavClick() {
  const button = document.getElementById("transcriptNavFloatingBtn");
  if (button?.dataset.action === "bottom") {
    scrollTranscriptToBottom();
  } else {
    scrollTranscriptToTop();
  }
}

// ============================================================
// UI STATE MANAGEMENT
// ============================================================

function showState(state) {
  document.getElementById("welcomeState").style.display =
    state === "welcome" ? "flex" : "none";
  document.getElementById("loadingState").style.display =
    state === "loading" ? "block" : "none";
  document.getElementById("errorState").style.display =
    state === "error" ? "block" : "none";
  const uploadEl = document.getElementById("uploadState");
  if (uploadEl) uploadEl.style.display = "none"; // Upload state removed — always hidden
  document.getElementById("resultsState").style.display =
    state === "results" ? "block" : "none";

  // The tab bar only belongs on the results view. We toggle it HERE, in one
  // place, so it tracks the view automatically. Previously each caller had to
  // remember to re-show it after showState("results"), and one path forgot —
  // which is why the tabs could vanish when re-opening an already-analyzed video.
  document.getElementById("tabsNav").style.display =
    state === "results" ? "flex" : "none";

  if (state !== "results") {
    stopPlaybackTracking();
  }
}

function updateLoading(title, subtitle) {
  document.getElementById("loadingText").textContent = title;
  document.getElementById("loadingSubtext").textContent = subtitle;
}

function showError(title, message) {
  errorAction = null;
  showState("error");
  document.getElementById("errorTitle").textContent = title;
  document.getElementById("errorMessage").textContent = message;
  document.getElementById("errorBtn").textContent = "Try Again";
}

function showConfigError(configStatus) {
  const missingKeys = [];
  if (!configStatus.hasSupadataKey) missingKeys.push("Supadata");
  if (!configStatus.hasAiKey) missingKeys.push("AI provider");

  showState("error");
  document.getElementById("errorTitle").textContent = "API Keys Missing";
  document.getElementById("errorMessage").textContent =
    `Add your ${missingKeys.join(" and ")} API key${missingKeys.length === 1 ? "" : "s"} in YouTube Digest Settings.`;
  document.getElementById("errorBtn").textContent = "Open Settings";
  errorAction = () => chrome.runtime.sendMessage({ action: "openOptions" });
}

// ============================================================
// TAB SWITCHING
// ============================================================

function switchTab(tabName) {
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.classList.toggle("active", tab.dataset.tab === tabName);
  });

  document.querySelectorAll(".tab-panel").forEach((panel) => {
    panel.classList.toggle("active", panel.dataset.panel === tabName);
  });

  // Start/stop playback tracking based on which tab is active
  if (tabName === "transcript") {
    startPlaybackTracking();
  } else {
    stopPlaybackTracking();
  }

  // Lazy-load LLM analysis when user switches to Overview tab
  if (tabName === "overview" && !currentAnalysis && !isAnalysisLoading) {
    triggerAnalysis();
  }
}

/**
 * Triggers the LLM analysis (lazy-loaded when user clicks Overview or Quotes tab).
 * This saves tokens by not running analysis until needed.
 */
async function triggerAnalysis() {
  if (!currentTranscriptTimestamped || isAnalysisLoading || currentAnalysis)
    return;

  isAnalysisLoading = true;

  // Show loading indicators in the Overview tab
  const chapterList = document.getElementById("chapterList");
  const quotesList = document.getElementById("quotesList");
  const summaryContainer = document.getElementById("analysisSummary");

  if (chapterList)
    chapterList.innerHTML =
      '<li class="chapter-item" style="color: var(--text-muted); border: none;">Loading chapters...</li>';
  if (summaryContainer)
    summaryContainer.innerHTML =
      '<div class="placeholder-text">Loading summary...</div>';
  if (quotesList)
    quotesList.innerHTML =
      '<div class="quote-item" style="color: var(--text-muted); border-left-color: var(--border);">Loading quotes...</div>';

  try {
    const analysisResult = await chrome.runtime.sendMessage({
      action: "analyzeTranscript",
      transcriptText: currentTranscriptTimestamped,
      videoTitle: currentVideoTitle,
      channelName: currentChannelName,
      videoDescription: currentVideoDescription,
      videoDuration: currentVideoDuration,
    });

    if (!analysisResult.success) {
      if (chapterList)
        chapterList.innerHTML = `<li class="chapter-item" style="color: var(--accent); border: none;">Analysis failed: ${escapeHtml(analysisResult.error || "Unknown error")}</li>`;
      isAnalysisLoading = false;
      return;
    }

    overviewOriginalAnalysis = analysisResult.analysis;
    overviewTranslations.set("en", overviewOriginalAnalysis);
    if (!overviewTranslations.has(overviewLanguage)) {
      const translated = await chrome.runtime.sendMessage({
        action: "translateOverviewContent",
        content: overviewOriginalAnalysis,
        targetLanguage: overviewLanguage,
      });
      if (translated.success) {
        overviewTranslations.set(overviewLanguage, translated.analysis);
      }
    }
    currentAnalysis =
      overviewTranslations.get(overviewLanguage) || overviewOriginalAnalysis;
    renderAnalysisResults(currentAnalysis);
    highlightMomentsOnPage(currentAnalysis.keyMoments);

    // Save to cache now that we have analysis
    await saveToCache(currentVideoId);
  } catch (error) {
    console.error("[YouTube Digest Panel] Analysis error:", error);
    if (chapterList)
      chapterList.innerHTML = `<li class="chapter-item" style="color: var(--accent); border: none;">Error: ${escapeHtml(error.message)}</li>`;
  }

  isAnalysisLoading = false;
}

// ============================================================
// TIMESTAMP / SEEK
// ============================================================

async function seekTo(seconds) {
  debugLog("[YouTube Digest Panel] seekTo called with:", seconds);
  if (seconds === undefined || seconds === null) {
    debugLog("[YouTube Digest Panel] seekTo aborted - no seconds value");
    return;
  }

  const payload = {
    action: "seekTo",
    seconds: Number(seconds),
    tabId: youtubeTabId || undefined,
    videoId: currentVideoId || undefined,
  };

  try {
    // Try direct messaging to the stored YouTube tab first (fastest/reliable)
    if (youtubeTabId) {
      try {
        await chrome.tabs.sendMessage(youtubeTabId, payload);
        debugLog("[YouTube Digest Panel] seekTo direct success");
        return;
      } catch (directErr) {
        debugLog(
          "[YouTube Digest Panel] Direct seekTo failed, falling back to relay:",
          directErr.message,
        );
      }
    }

    // Fallback: route through background script
    const result = await chrome.runtime.sendMessage({
      action: "relayToContent",
      payload,
    });
    debugLog("[YouTube Digest Panel] seekTo relay result:", result);
  } catch (error) {
    console.error("[YouTube Digest Panel] seekTo error:", error);
  }
}

/**
 * Plays a saved note at its timestamp.
 * - If the note belongs to the video currently open, we seek the player in place.
 * - If it belongs to a DIFFERENT video (e.g. viewing "All Notes"), seeking the
 *   current player would jump to the wrong content, so we open that video in a
 *   new tab at the right timestamp instead.
 */
function playNote(note) {
  if (note.videoId && note.videoId === currentVideoId) {
    seekTo(note.timestampSeconds);
  } else {
    // note.timestampedUrl already includes the &t=<seconds>s anchor
    chrome.tabs.create({ url: note.timestampedUrl });
  }
}

async function highlightMomentsOnPage(moments) {
  if (!moments || !moments.length) return;

  try {
    // Route through background script for reliable message passing
    await chrome.runtime.sendMessage({
      action: "relayToContent",
      payload: {
        action: "highlightMoments",
        moments: moments,
        videoDuration: currentVideoDuration,
      },
    });
  } catch (error) {
    console.error("Highlight error:", error);
  }
}

// ============================================================
// UTILITY
// ============================================================

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text || "";
  return div.innerHTML;
}

/**
 * Renders the small subset of inline formatting commonly present in subtitle
 * tracks and model translations. Everything is escaped first; only exact,
 * attribute-free allowlisted tags are restored as markup afterwards.
 */
function renderSubtitleInlineMarkup(text) {
  return escapeHtml(text).replace(
    /&lt;(\/?)(i|em|b|strong|u)&gt;|&lt;br(?:\s*\/)?&gt;/gi,
    (_match, closing, tagName) =>
      tagName ? `<${closing}${tagName.toLowerCase()}>` : "<br>",
  );
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    console.error("Copy failed:", error);
    return false;
  }
}

async function copyToClipboardWithFeedback(text, buttonId) {
  const btn = document.getElementById(buttonId);
  const original = btn.textContent;

  const success = await copyToClipboard(text);
  if (success) {
    btn.textContent = "✓ Copied";
    setTimeout(() => {
      btn.textContent = original;
    }, 2000);
  }
}

function downloadTextFile(text, filename) {
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function sanitizeFilename(str) {
  return (str || "untitled")
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .substring(0, 50)
    .toLowerCase();
}

// ============================================================
// TEXT SELECTION — EXPLAIN FEATURE
// ============================================================

/**
 * Sets up text selection handling in the transcript.
 * When user selects text, shows an "Explain" button.
 */
function setupExplainFeature() {
  const transcriptList = document.getElementById("transcriptList");
  if (!transcriptList) return;

  // Remove existing tooltip if any
  const existingTooltip = document.getElementById("explainTooltip");
  if (existingTooltip) existingTooltip.remove();

  // Create the explain tooltip/button
  const tooltip = document.createElement("div");
  tooltip.id = "explainTooltip";
  tooltip.className = "explain-tooltip";
  tooltip.innerHTML = `<button class="explain-btn">💡 Explain</button>`;
  tooltip.style.display = "none";
  document.body.appendChild(tooltip);

  let selectedText = "";

  // Interacting with Explain must preserve the transcript selection and stay
  // isolated from document/row click behavior.
  tooltip.addEventListener("mousedown", (event) => {
    event.preventDefault();
    event.stopPropagation();
  });
  tooltip.addEventListener("mouseup", (event) => {
    event.stopPropagation();
  });
  tooltip.addEventListener("click", (event) => {
    event.stopPropagation();
  });

  // Listen for text selection
  document.addEventListener("mouseup", (e) => {
    const selection = window.getSelection();
    const text = selection.toString().trim();

    // Only show if selecting within transcript
    const isInTranscript = transcriptList.contains(selection.anchorNode);

    // Allow any selection length (removed 10+ char requirement)
    if (text.length > 0 && isInTranscript) {
      selectedText = text;

      // Position the tooltip near the selection
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();

      tooltip.style.display = "block";
      tooltip.style.top = `${rect.bottom + window.scrollY + 8}px`;
      tooltip.style.left = `${rect.left + rect.width / 2}px`;
    } else {
      tooltip.style.display = "none";
    }
  });

  // Hide tooltip when clicking elsewhere
  document.addEventListener("mousedown", (e) => {
    if (!tooltip.contains(e.target)) {
      tooltip.style.display = "none";
    }
  });

  // Handle explain button click
  tooltip
    .querySelector(".explain-btn")
    .addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (!selectedText) return;

      tooltip.style.display = "none";
      await showExplanation(selectedText);
    });
}

/**
 * Shows the explanation modal and fetches it from the configured AI provider.
 */
async function showExplanation(selectedText) {
  // Create modal
  const modal = document.createElement("div");
  modal.id = "explainModal";
  modal.className = "explain-modal-overlay";
  modal.innerHTML = `
    <div class="explain-modal">
      <div class="explain-modal-header">
        <div class="explain-modal-title">Explain</div>
        <button class="explain-modal-close" id="closeExplain">✕</button>
      </div>
      <div class="explain-selected-text">"${escapeHtml(selectedText.substring(0, 200))}${selectedText.length > 200 ? "..." : ""}"</div>
      <div class="explain-modal-content" id="explanationContent">
        <div class="explain-loading">
          <div class="loading-bar"></div>
          <span>Analyzing...</span>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  // Close handlers
  document
    .getElementById("closeExplain")
    .addEventListener("click", () => modal.remove());
  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.remove();
  });

  // Get some context around the selection from the transcript
  const transcriptContext = getTranscriptContext(selectedText);

  // Fetch explanation
  try {
    const result = await chrome.runtime.sendMessage({
      action: "explainSelection",
      selectedText: selectedText,
      transcriptContext: transcriptContext,
      videoTitle: currentVideoTitle,
    });

    const contentDiv = document.getElementById("explanationContent");
    if (result.success) {
      contentDiv.innerHTML = `<div class="explain-text">${escapeHtml(result.explanation).replace(/\n\n/g, "</p><p>").replace(/\n/g, "<br>")}</div>`;
    } else {
      contentDiv.innerHTML = `<div class="explain-error">Failed to get explanation: ${escapeHtml(result.error)}</div>`;
    }
  } catch (error) {
    const contentDiv = document.getElementById("explanationContent");
    contentDiv.innerHTML = `<div class="explain-error">Error: ${escapeHtml(error.message)}</div>`;
  }
}

/**
 * Gets surrounding context from the transcript for the selected text.
 */
function getTranscriptContext(selectedText) {
  const fullText = currentTranscriptText || "";
  const index = fullText.indexOf(selectedText);

  if (index === -1) return "";

  // Get 200 chars before and after
  const start = Math.max(0, index - 200);
  const end = Math.min(fullText.length, index + selectedText.length + 200);

  return fullText.substring(start, end);
}

// ============================================================
// CACHING
// ============================================================

/**
 * Saves the current digest results to persistent local storage.
 * Results survive browser restarts — reopening the same video loads from cache
 * without consuming API tokens or Supadata calls.
 * Cache expires after 30 days. Oldest entries evicted when > 20 videos cached.
 */
async function saveToCache(videoId) {
  if (!videoId || !currentTranscript) return;

  try {
    // Persist semantic-segment translations for this video.
    const paragraphCacheForVideo = {};
    for (const [key, value] of transcriptParagraphCache.entries()) {
      if (key.startsWith(`${videoId}:`)) {
        paragraphCacheForVideo[key] = value;
      }
    }

    const cacheData = {
      cacheVersion: CACHE_VERSION,
      analysis: currentAnalysis, // May be null if not yet analyzed
      transcript: currentTranscript,
      transcriptText: currentTranscriptText,
      transcriptTimestamped: currentTranscriptTimestamped,
      transcriptLanguage: currentTranscriptLanguage,
      videoTitle: currentVideoTitle,
      channelName: currentChannelName,
      paragraphCache: paragraphCacheForVideo,
      timestamp: Date.now(),
    };

    await chrome.storage.local.set({ [`digest_${videoId}`]: cacheData });
    debugLog(
      "Saved to cache:",
      videoId,
      currentAnalysis ? "(with analysis)" : "(transcript only)",
    );

    // Evict old entries if we have more than 20 videos cached
    await evictOldCacheEntries(20);
  } catch (error) {
    console.error("Cache save error:", error);
  }
}

/**
 * Keeps the cache from growing unbounded.
 * Removes the oldest entries when we exceed maxEntries videos.
 *
 * @param {number} maxEntries - Maximum number of cached videos to keep
 */
async function evictOldCacheEntries(maxEntries) {
  try {
    const allData = await chrome.storage.local.get(null);
    let digestKeys = Object.keys(allData).filter((k) =>
      k.startsWith("digest_"),
    );
    const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
    const expired = digestKeys.filter((key) => {
      const timestamp = Number(allData[key]?.timestamp) || 0;
      return Date.now() - timestamp > THIRTY_DAYS;
    });
    if (expired.length) {
      await chrome.storage.local.remove(expired);
      const expiredSet = new Set(expired);
      digestKeys = digestKeys.filter((key) => !expiredSet.has(key));
    }

    if (digestKeys.length <= maxEntries) return;

    // Sort by timestamp (oldest first) and remove excess
    const sorted = digestKeys
      .map((k) => ({ key: k, ts: allData[k]?.timestamp || 0 }))
      .sort((a, b) => a.ts - b.ts);

    const toRemove = sorted
      .slice(0, sorted.length - maxEntries)
      .map((e) => e.key);
    if (toRemove.length > 0) {
      await chrome.storage.local.remove(toRemove);
      debugLog(`[YouTube Digest] Evicted ${toRemove.length} old cache entries`);
    }
  } catch (error) {
    console.error("Cache eviction error:", error);
  }
}

/**
 * Loads digest results from persistent local storage.
 * Returns null if not cached or expired (30-day expiry).
 */
async function loadFromCache(videoId) {
  if (!videoId) return null;

  try {
    const result = await chrome.storage.local.get(`digest_${videoId}`);
    const cached = result[`digest_${videoId}`];

    if (!cached) return null;

    if (cached.cacheVersion !== CACHE_VERSION) {
      await chrome.storage.local.remove(`digest_${videoId}`);
      return null;
    }

    // Cache expires after 30 days
    const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
    if (Date.now() - cached.timestamp > THIRTY_DAYS) {
      await chrome.storage.local.remove(`digest_${videoId}`);
      return null;
    }

    return cached;
  } catch (error) {
    console.error("Cache load error:", error);
    return null;
  }
}

/**
 * Updates the cache after enhance or translation operations.
 */
async function updateCache() {
  if (currentVideoId) {
    await saveToCache(currentVideoId);
  }
}

// ============================================================
// NOTES
// ============================================================

/**
 * Loads and renders notes from storage.
 * @param {string|null} videoId - Filter by video ID, or null for all notes
 */
async function loadNotes(videoId) {
  try {
    const result = await chrome.runtime.sendMessage({
      action: "getNotes",
      videoId: videoId,
    });

    if (result.success) {
      renderNotes(result.notes, videoId);
    }
  } catch (error) {
    console.error("[YouTube Digest Panel] Load notes error:", error);
  }
}

/**
 * Renders the notes list in the Notes tab.
 */
function renderNotes(notes, filteredVideoId) {
  const notesList = document.getElementById("notesList");
  const notesIntro = document.getElementById("notesIntro");

  if (!notesList) return;

  notesList.innerHTML = "";

  if (!notes || notes.length === 0) {
    notesIntro.style.display = "block";
    notesIntro.textContent = filteredVideoId
      ? "No notes for this video yet. Hover over the video and click 📝 Note to save."
      : "No notes saved yet. Hover over a video and click 📝 Note to save.";
    return;
  }

  notesIntro.style.display = "none";

  notes.forEach((note) => {
    const noteEl = document.createElement("div");
    noteEl.className = "note-item";
    noteEl.innerHTML = `
      <div class="note-header">
        <span class="note-timestamp" data-url="${escapeHtml(note.timestampedUrl)}" data-seconds="${Number(note.timestampSeconds) || 0}">${escapeHtml(note.timestamp)}</span>
        ${!filteredVideoId ? `<span class="note-video-title">${escapeHtml(note.videoTitle)}</span>` : ""}
        <button class="note-delete" data-id="${escapeHtml(note.id)}" title="Delete note">✕</button>
      </div>
      ${note.imageDataUrl ? `<img class="note-image" src="${escapeHtml(note.imageDataUrl)}" alt="Video frame">` : ""}
      <div class="note-text">"${escapeHtml(note.text)}"</div>
      <div class="note-actions">
        <button class="note-action-btn note-docs-btn">Google Docs</button>
        <button class="note-action-btn note-shimo-btn">石墨</button>
        <button class="note-action-btn note-copy-text">⧉ Copy text</button>
        <button class="note-action-btn note-copy-link" data-url="${escapeHtml(note.timestampedUrl)}">🔗 Copy timestamp</button>
        <button class="note-action-btn note-play" data-seconds="${Number(note.timestampSeconds) || 0}">▶ Play</button>
      </div>
    `;

    // Timestamp click - play from this point (in this tab or a new one)
    noteEl.querySelector(".note-timestamp").addEventListener("click", () => {
      playNote(note);
    });

    // Delete button
    noteEl
      .querySelector(".note-delete")
      .addEventListener("click", async (e) => {
        e.stopPropagation();
        await deleteNote(note.id);
        loadNotes(filteredVideoId);
      });

    // Google Docs button — copies rich text plus the image, then opens a new doc.
    noteEl.querySelector(".note-docs-btn").addEventListener("click", async () => {
      const btn = noteEl.querySelector(".note-docs-btn");
      btn.textContent = "Copying…";
      try {
        await exportNoteToDocs(note);
        btn.textContent = "✓ Docs";
      } catch (error) {
        btn.textContent = "Error";
        console.error("Google Docs export failed:", error);
      }
      setTimeout(() => {
        btn.textContent = "Google Docs";
      }, 2000);
    });

    noteEl.querySelector(".note-shimo-btn").addEventListener("click", async () => {
      const btn = noteEl.querySelector(".note-shimo-btn");
      btn.textContent = "Copying…";
      try {
        await exportNoteToShimo(note);
        btn.textContent = "✓ 石墨";
      } catch (error) {
        btn.textContent = "Error";
        console.error("Shimo export failed:", error);
      }
      setTimeout(() => {
        btn.textContent = "石墨";
      }, 2000);
    });

    // Copy text button — copies just the note's text
    noteEl
      .querySelector(".note-copy-text")
      .addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(note.text);
          const btn = noteEl.querySelector(".note-copy-text");
          btn.textContent = "✓ Copied!";
          setTimeout(() => {
            btn.textContent = "⧉ Copy text";
          }, 2000);
        } catch (err) {
          console.error("Copy failed:", err);
        }
      });

    // Copy timestamp button — copies the timestamped YouTube link
    noteEl
      .querySelector(".note-copy-link")
      .addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(note.timestampedUrl);
          const btn = noteEl.querySelector(".note-copy-link");
          btn.textContent = "✓ Copied!";
          setTimeout(() => {
            btn.textContent = "🔗 Copy timestamp";
          }, 2000);
        } catch (err) {
          console.error("Copy failed:", err);
        }
      });

    // Play button (in this tab if it's the current video, else a new tab)
    noteEl.querySelector(".note-play").addEventListener("click", () => {
      playNote(note);
    });

    notesList.appendChild(noteEl);
  });
}

/**
 * Copies a note as Google Docs-compatible rich text and opens a new document.
 * Google Docs has no public create-from-clipboard URL, so the user pastes the
 * prepared note into the newly opened doc.
 */
function buildNoteExportHtml(note) {
  const title = `${note.videoTitle || "YouTube Digest Note"} @ ${note.timestamp}`;
  const plainText = `${title}\n${note.timestampedUrl}\n\n${note.text || ""}`;
  const imageHtml = note.imageDataUrl
    ? `<img src="${escapeHtml(note.imageDataUrl)}" style="max-width:100%;">`
    : "";
  const html = `<meta charset="utf-8"><title>${escapeHtml(title)}</title><h1>${escapeHtml(title)}</h1><p><a href="${escapeHtml(note.timestampedUrl)}">${escapeHtml(note.timestamp)}</a></p>${imageHtml}<p>${escapeHtml(note.text || "")}</p>`;
  return { title, plainText, html };
}

async function copyNoteToClipboard(note) {
  const { plainText, html } = buildNoteExportHtml(note);
  try {
    if (navigator.clipboard?.write && typeof ClipboardItem !== "undefined") {
      await navigator.clipboard.write([
        new ClipboardItem({
          "text/html": new Blob([html], { type: "text/html" }),
          "text/plain": new Blob([plainText], { type: "text/plain" }),
        }),
      ]);
    } else {
      await navigator.clipboard.writeText(plainText);
    }
  } catch (error) {
    console.error("[YouTube Digest] Note clipboard export error:", error);
    throw error;
  }
}

async function exportNoteToDocs(note) {
  await copyNoteToClipboard(note);
  await chrome.tabs.create({
    url: "https://docs.new",
  });
}

async function exportNoteToShimo(note) {
  await copyNoteToClipboard(note);
  await chrome.tabs.create({
    url: "https://shimo.im/docs/new",
  });
}

async function getAllNotes() {
  const result = await chrome.runtime.sendMessage({
    action: "getNotes",
  });
  if (!result.success) {
    throw new Error(result.error || "Could not load notes");
  }
  return result.notes || [];
}

function buildNotesExportHtml(notes) {
  const sections = notes.map((note) => {
    const title = `${note.videoTitle || "YouTube Digest Note"} @ ${note.timestamp}`;
    const imageHtml = note.imageDataUrl
      ? `<img src="${escapeHtml(note.imageDataUrl)}" style="max-width:100%;">`
      : "";
    return `<section><h2>${escapeHtml(title)}</h2><p><a href="${escapeHtml(note.timestampedUrl)}">${escapeHtml(note.timestamp)}</a></p>${imageHtml}<p>${escapeHtml(note.text || "")}</p></section>`;
  });
  const html = `<meta charset="utf-8"><title>YouTube Digest Notes</title><h1>YouTube Digest Notes</h1>${sections.join("<hr>")}`;
  const plainText = `YouTube Digest Notes\n\n${notes
    .map((note) => {
      const title = `${note.videoTitle || "YouTube Digest Note"} @ ${note.timestamp}`;
      return `${title}\n${note.timestampedUrl}\n\n${note.text || ""}`;
    })
    .join("\n\n---\n\n")}`;
  return { plainText, html };
}

async function copyNotesToClipboard(notes) {
  const { plainText, html } = buildNotesExportHtml(notes);
  try {
    if (navigator.clipboard?.write && typeof ClipboardItem !== "undefined") {
      await navigator.clipboard.write([
        new ClipboardItem({
          "text/html": new Blob([html], { type: "text/html" }),
          "text/plain": new Blob([plainText], { type: "text/plain" }),
        }),
      ]);
    } else {
      await navigator.clipboard.writeText(plainText);
    }
  } catch (error) {
    console.error("[YouTube Digest] Notes clipboard export error:", error);
    throw error;
  }
}

async function exportAllNotesToDocs() {
  const notes = await getAllNotes();
  if (!notes.length) throw new Error("No notes to export");
  await copyNotesToClipboard(notes);
  await chrome.tabs.create({ url: "https://docs.new" });
}

async function exportAllNotesToShimo() {
  const notes = await getAllNotes();
  if (!notes.length) throw new Error("No notes to export");
  await copyNotesToClipboard(notes);
  await chrome.tabs.create({ url: "https://shimo.im/docs/new" });
}

/**
 * Deletes a note by ID.
 */
async function deleteNote(noteId) {
  try {
    await chrome.runtime.sendMessage({
      action: "deleteNote",
      noteId: noteId,
    });
  } catch (error) {
    console.error("[YouTube Digest Panel] Delete note error:", error);
  }
}

// ============================================================
// AUTO-SCROLL — Follow video playback in transcript
// ============================================================
// While a video plays, the transcript automatically scrolls to show which
// 30-second chunk is currently being spoken. If the user manually scrolls
// (e.g., to read ahead), auto-scroll pauses and a "Follow playback" button
// appears so they can resume it. Highlight always stays active regardless.

/**
 * Starts polling the video's current time and highlighting/scrolling
 * to the matching transcript entry.
 */
function startPlaybackTracking() {
  if (!currentTranscript || !currentTranscript.length) return;

  // Don't restart if already tracking (preserves user's auto-scroll state)
  if (autoScrollInterval) return;

  autoScrollEnabled = true;
  document.getElementById("followPlaybackBtn").style.display = "none";

  // Poll video time frequently so scrolling stays tightly synced with speech.
  autoScrollInterval = setInterval(() => playbackTrackingTick(), 100);

  // Listen for manual scrolls on the content area
  const contentArea = document.getElementById("contentArea");
  contentArea.removeEventListener("scroll", onContentAreaScroll);
  contentArea.addEventListener("scroll", onContentAreaScroll);
}

/**
 * Stops playback tracking entirely. Called when leaving transcript tab,
 * starting a new digest, or leaving results state.
 */
function stopPlaybackTracking() {
  if (autoScrollInterval) {
    clearInterval(autoScrollInterval);
    autoScrollInterval = null;
  }
  autoScrollEnabled = true; // Reset for next time
  lastAutoScrollTime = 0;
  document.getElementById("followPlaybackBtn").style.display = "none";

  // Remove active highlights
  document
    .querySelectorAll(".transcript-entry.active-playback")
    .forEach((el) => {
      el.classList.remove("active-playback");
    });
}

/**
 * One tick of the playback tracker. Gets current video time from the
 * YouTube tab and highlights + scrolls to the matching transcript entry.
 */
async function playbackTrackingTick() {
  if (playbackTrackingRunning) return;
  playbackTrackingRunning = true;
  try {
    await playbackTrackingTickInternal();
  } finally {
    playbackTrackingRunning = false;
  }
}

async function playbackTrackingTickInternal() {
  let currentTime = null;
  let paused = null;

  if (youtubeTabId) {
    try {
      const response = await chrome.tabs.sendMessage(youtubeTabId, {
        action: "getCurrentTime",
      });
      currentTime = response?.currentTime;
      paused = response?.paused;
    } catch (_error) {
      // Fall through to the background relay below.
    }
  }

  if (typeof currentTime !== "number") {
    try {
      const result = await chrome.runtime.sendMessage({
        action: "relayToContent",
        payload: { action: "getCurrentTime" },
      });
      currentTime = result?.response?.currentTime;
      paused = result?.response?.paused;
    } catch (error) {
      // Silently ignore — YouTube tab might be closed or navigated away.
    }
  }

  if (typeof currentTime === "number") {
    if (paused === false) {
      autoScrollEnabled = true;
      document.getElementById("followPlaybackBtn").style.display = "none";
    }
    highlightActiveEntry(currentTime + subtitleSyncOffset);
  }
}

/**
 * Scrolls the transcript to the entry currently being spoken (the one
 * carrying the active-playback highlight). Returns false if nothing is
 * highlighted yet. Stamps lastAutoScrollTime BEFORE scrolling so the scroll
 * events from our own smooth animation aren't mistaken for the user
 * scrolling away (which would re-disable auto-scroll immediately).
 */
function scrollToActiveEntry() {
  const activeEntry = document.querySelector(
    "#transcriptList .transcript-entry.active-playback",
  );
  if (!activeEntry) return false;

  lastAutoScrollTime = Date.now();
  activeEntry.scrollIntoView({ behavior: "smooth", block: "center" });
  return true;
}

/**
 * Finds the transcript entry matching the current playback time,
 * highlights it, and scrolls to it (if auto-scroll is enabled).
 *
 * @param {number} currentSeconds - Current video playback time in seconds
 */
function getTranscriptEntryRange(entry, entries, index) {
  const start = Number(entry.dataset.seconds) || 0;
  const next = entries[index + 1]
    ? Number(entries[index + 1].dataset.seconds)
    : Infinity;
  return { start, end: next };
}

function applyActiveEntryHighlight(activeEntry, currentSeconds, activeStart, activeEnd) {
  const transcriptList = activeEntry.closest("#transcriptList");
  if (!transcriptList) return;
  const entries = transcriptList.querySelectorAll(".transcript-entry");

  entries.forEach((entry) => {
    entry.classList.remove("active-playback");
    entry.style.removeProperty("--lyric-progress");
    entry.querySelectorAll(".transcript-line").forEach((line) => {
      line.classList.remove("active-line");
      line.style.removeProperty("--lyric-progress");
    });
  });
  activeEntry.classList.add("active-playback");

  const activeLine = [...activeEntry.querySelectorAll(".transcript-line")].find(
    (line) => {
      const lineStart = Number(line.dataset.start) || 0;
      const lineEnd = Number(line.dataset.end) || Infinity;
      return currentSeconds >= lineStart && currentSeconds < lineEnd;
    },
  );
  if (activeLine) {
    const lineStart = Number(activeLine.dataset.start) || 0;
    const lineEnd = Number(activeLine.dataset.end) || activeEnd;
    activeLine.classList.add("active-line");
    const progress = computeLyricProgress(currentSeconds, lineStart, lineEnd);
    activeLine.style.setProperty(
      "--lyric-progress",
      `${(progress * 100).toFixed(2)}%`,
    );
  } else {
    const progress = computeLyricProgress(
      currentSeconds,
      activeStart,
      activeEnd,
    );
    activeEntry.style.setProperty(
      "--lyric-progress",
      `${(progress * 100).toFixed(2)}%`,
    );
  }

  if (autoScrollEnabled) {
    lastAutoScrollTime = Date.now();
    activeEntry.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}

function highlightActiveEntry(currentSeconds) {
  const transcriptList = document.getElementById("transcriptList");
  if (!transcriptList) return;
  const entries = transcriptList.querySelectorAll(".transcript-entry");
  if (entries.length === 0) return;

  let activeEntry = null;
  let activeStart = 0;
  let activeEnd = 0;
  entries.forEach((entry, index) => {
    const entrySeconds = Number(entry.dataset.seconds);
    const nextEntry = entries[index + 1];
    const nextSeconds = nextEntry
      ? Number(nextEntry.dataset.seconds)
      : Infinity;

    if (currentSeconds >= entrySeconds && currentSeconds < nextSeconds) {
      activeEntry = entry;
      activeStart = entrySeconds;
      activeEnd = nextSeconds;
    }
  });

  if (!activeEntry) return;
  applyActiveEntryHighlight(activeEntry, currentSeconds, activeStart, activeEnd);
}

function highlightActiveEntryByText(currentSeconds, nativeText) {
  const transcriptList = document.getElementById("transcriptList");
  if (!transcriptList) return;
  const entries = transcriptList.querySelectorAll(".transcript-entry");
  if (entries.length === 0) return;

  let bestEntry = null;
  let bestScore = 0;
  entries.forEach((entry) => {
    const original =
      [...entry.querySelectorAll(".transcript-line")]
        .map((line) => line.textContent?.trim() || "")
        .filter(Boolean)
        .join(" ") ||
      entry.querySelector(".transcript-original")?.textContent?.trim() ||
      entry.querySelector(".transcript-text")?.textContent?.trim() ||
      "";
    const score = captionSimilarity(nativeText, original);
    if (score > bestScore) {
      bestScore = score;
      bestEntry = entry;
    }
  });

  if (!bestEntry || bestScore < 0.35) {
    highlightActiveEntry(currentSeconds);
    return;
  }
  const index = Array.from(entries).indexOf(bestEntry);
  const range = getTranscriptEntryRange(bestEntry, entries, index);
  applyActiveEntryHighlight(
    bestEntry,
    currentSeconds,
    range.start,
    range.end,
  );
}

function computeLyricProgress(currentSeconds, startSeconds, endSeconds) {
  const duration = Math.max(0.1, Number(endSeconds) - Number(startSeconds));
  return Math.min(
    1,
    Math.max(0, (Number(currentSeconds) - Number(startSeconds)) / duration),
  );
}

/**
 * Scroll event handler for the content area.
 * Detects manual scrolling and disables auto-scroll so the user
 * can read at their own pace without being yanked back.
 */
function onContentAreaScroll() {
  // Ignore scroll events within 1 second of a programmatic scroll
  // (smooth scroll animations can last longer than a simple boolean flag)
  if (Date.now() - lastAutoScrollTime < 300) return;

  // User scrolled manually — disable auto-scroll and show the button
  if (autoScrollEnabled && autoScrollInterval) {
    autoScrollEnabled = false;
    document.getElementById("followPlaybackBtn").style.display = "block";
  }
  updateTranscriptNavVisibility();
}

// ============================================================
// TRANSCRIPT MODE UI — Original / Chinese / Japanese / aligned bilingual
// ============================================================

function getOriginalTranscriptLabel() {
  const language = String(currentTranscriptLanguage || "").trim();
  const label =
    { en: "English", ja: "日本語", zh: "简体中文" }[language] || language;
  return /^[A-Za-z0-9-]{1,20}$/.test(language) && label
    ? `Original (${label})`
    : "Original";
}

function getActiveTranscriptSegments() {
  return groupTranscriptEntries(currentTranscript || []);
}

function shouldStartTranscriptParagraph(previousStart, currentStart) {
  return (
    previousStart !== null &&
    previousStart !== undefined &&
    Number(currentStart) - Number(previousStart) >=
      TRANSCRIPT_PARAGRAPH_GAP_SECONDS
  );
}

function defaultTranscriptModeForLanguage(language) {
  if (language === "ja") return "bilingual-ja";
  if (language === "en") return "bilingual-en";
  return "zh";
}

function applyDetectedTranscriptLanguage(language) {
  if (transcriptModeUserSelected || !language) return;
  const nextMode = defaultTranscriptModeForLanguage(language);
  if (nextMode !== currentTranscriptMode) {
    currentTranscriptMode = nextMode;
    updateTranscriptModeSelect();
  }
}

async function loadTranscriptModePreference() {
  try {
    const stored = await chrome.storage.local.get(YTD_SETTINGS.STORAGE_KEY);
    const settings = YTD_SETTINGS.normalize(
      stored[YTD_SETTINGS.STORAGE_KEY],
    );
    if (YTD_SETTINGS.TRANSCRIPT_MODES.includes(settings.transcriptMode)) {
      currentTranscriptMode = settings.transcriptMode;
      transcriptModeUserSelected = true;
      transcriptModeFromSettings = true;
    }
  } catch (error) {
    console.warn("[YouTube Digest] Transcript mode preference unavailable:", error.message);
  }
}

async function persistTranscriptMode(mode) {
  try {
    const stored = await chrome.storage.local.get(YTD_SETTINGS.STORAGE_KEY);
    const settings = YTD_SETTINGS.normalize(
      stored[YTD_SETTINGS.STORAGE_KEY],
    );
    settings.transcriptMode = mode;
    await chrome.storage.local.set({
      [YTD_SETTINGS.STORAGE_KEY]: settings,
    });
  } catch (error) {
    console.warn(
      "[YouTube Digest] Transcript mode preference not persisted:",
      error.message,
    );
  }
}

async function loadOverlayModePreference() {
  try {
    const stored = await chrome.storage.local.get("ytd_overlay_mode");
    const mode = stored.ytd_overlay_mode;
    if (mode === "below" || mode === "above" || mode === "off") {
      transcriptOverlayMode = mode;
    }
    const select = document.getElementById("overlayModeSelect");
    if (select) select.value = transcriptOverlayMode;
  } catch (error) {
    console.warn(
      "[YouTube Digest] Overlay mode preference unavailable:",
      error.message,
    );
  }
}

async function loadOverlayStylePreference() {
  try {
    const stored = await chrome.storage.local.get(YTD_SETTINGS.STORAGE_KEY);
    const settings = YTD_SETTINGS.normalize(
      stored[YTD_SETTINGS.STORAGE_KEY],
    );
    overlayStyle = YTD_SETTINGS.OVERLAY_STYLES.includes(settings.overlayStyle)
      ? settings.overlayStyle
      : "normal";
    const numericOffset = Number(settings.subtitleSyncOffset);
    subtitleSyncOffset = Number.isFinite(numericOffset)
      ? Math.min(2, Math.max(-2, numericOffset))
      : 0;
  } catch (error) {
    console.warn(
      "[YouTube Digest] Overlay style preference unavailable:",
      error.message,
    );
  }
}

function getTranscriptTargetLanguage(mode) {
  if (mode === "ja") return "ja";
  return "zh";
}

function translationTargetMatchesSource(mode, sourceLanguage = currentTranscriptLanguage) {
  const target = getTranscriptTargetLanguage(mode);
  return Boolean(
    sourceLanguage && target && target === sourceLanguage,
  );
}

function transcriptTranslationCacheKey(segment) {
  return `${currentVideoId}:${getTranscriptTargetLanguage(currentTranscriptMode)}:semantic:${segment.id}`;
}

function updateTranscriptModeSelect() {
  const select = document.getElementById("transcriptModeSelect");
  if (select) select.value = currentTranscriptMode;
}

async function handleTranscriptModeChange(mode) {
  if (!["original", "zh", "ja", "bilingual-en", "bilingual-ja"].includes(mode)) {
    return;
  }
  if (mode === currentTranscriptMode) return;

  currentTranscriptMode = mode;
  translationGeneration += 1;
  translationWorkCount = 0;
  setTranslatingSpinner(false);
  if (transcriptScrollObserver) transcriptScrollObserver.disconnect();
  transcriptScrollObserver = null;
  updateTranscriptModeSelect();

  if (mode !== "original" && translationTargetMatchesSource(mode)) {
    currentTranscriptMode = "original";
    updateTranscriptModeSelect();
    renderTranscript();
    return;
  }

  if (mode === "original") {
    renderTranscript();
    return;
  }

  await translateTranscript();
}

function renderTranscriptSegmentContent(segment, mode, translated, error) {
  const original =
    renderTranscriptLines(segment.lines) ||
    renderSubtitleInlineMarkup(segment.text);
  let translationHtml = "";
  if (translated) {
    translationHtml = renderSubtitleInlineMarkup(translated);
  } else if (error) {
    translationHtml = `${escapeHtml(error)}<button class="translation-retry-btn" type="button">Retry</button>`;
  } else {
    translationHtml = "Waiting for translation…";
  }

  if (mode === "bilingual-en" || mode === "bilingual-ja") {
    return `<span class="transcript-copy"><span class="transcript-original">${original}</span><span class="transcript-translation ${translated ? "" : error ? "translation-error" : "translation-pending"}">${translationHtml}</span></span>`;
  }

  return `<span class="transcript-copy"><span class="transcript-translation ${translated ? "" : error ? "translation-error" : "translation-pending"}">${translationHtml}</span></span>`;
}

function renderTranscriptLines(lines) {
  if (!Array.isArray(lines) || lines.length === 0) return null;
  let html = "";
  lines.forEach((line, index) => {
    if (index > 0) {
      const previous = lines[index - 1].text;
      const current = line.text;
      const cjkPair =
        /[\u3040-\u30ff\u3400-\u9fff]/.test(previous) &&
        /[\u3040-\u30ff\u3400-\u9fff]/.test(current);
      html += cjkPair ? "" : " ";
    }
    html += `<span class="transcript-line" data-start="${Number(line.start)}" data-end="${Number(line.end)}">${renderSubtitleInlineMarkup(line.text)}</span>`;
  });
  return html;
}

function renderTranscriptModeRows(segments, mode) {
  const transcriptList = document.getElementById("transcriptList");
  if (!transcriptList) return [];
  transcriptList.innerHTML = "";

  const existingBadge = document.getElementById("transcriptSourceBadge");
  if (existingBadge) existingBadge.remove();
  const badge = document.createElement("div");
  badge.id = "transcriptSourceBadge";
  badge.className = "transcript-source-badge";
  const originalLabel = getOriginalTranscriptLabel();
  const modeLabel =
    mode === "bilingual-en"
      ? `英语-双语 · translated from ${originalLabel}`
      : mode === "bilingual-ja"
        ? `日语-双语 · translated from ${originalLabel}`
      : mode === "ja"
        ? `日本語 · translated from ${originalLabel}`
        : mode === "zh"
          ? `简体中文 · translated from ${originalLabel}`
          : originalLabel;
  badge.innerHTML = `<span class="source-dot source-dot--subs"></span> From video subtitles · ${modeLabel}`;
  transcriptList.parentElement.insertBefore(badge, transcriptList);

  const rows = [];
  segments.forEach((segment, index) => {
    const div = document.createElement("div");
    const cached = transcriptParagraphCache.get(
      transcriptTranslationCacheKey(segment),
    );
    const previousStart = index > 0 ? segments[index - 1].start : null;
    const paragraphBreak = shouldStartTranscriptParagraph(
      previousStart,
      segment.start,
    );
    div.className = `transcript-entry ${cached ? "translated" : "translating"}${paragraphBreak ? " paragraph-break" : ""}`;
    div.dataset.seconds = segment.start;
    div.dataset.segmentId = segment.id;
    div.dataset.segmentIndex = index;

    const minutes = Math.floor(segment.start / 60);
    const seconds = Math.floor(segment.start % 60);
    const timestamp = `${minutes}:${String(seconds).padStart(2, "0")}`;
    div.innerHTML = `
      <span class="transcript-time">${timestamp}</span>
      ${renderTranscriptSegmentContent(segment, mode, cached, "")}
    `;
    div.addEventListener("click", (event) =>
      seekFromTranscriptEntryClick(event, segment.start),
    );
    div.querySelector(".transcript-time").addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      seekTo(segment.start);
    });
    transcriptList.appendChild(div);
    rows.push(div);
  });

  startPlaybackTracking();
  updateTranscriptNavVisibility();
  syncTranscriptOverlay();
  return rows;
}

/**
 * Rebuilds a provider response in source order. Unknown IDs are ignored and
 * missing IDs remain explicit errors, never positional guesses.
 */
function alignTranslatedSegmentBatch(sourceSegments, responseSegments) {
  const translatedById = new Map();
  if (Array.isArray(responseSegments)) {
    responseSegments.forEach((item) => {
      if (!item || typeof item.id !== "string" || typeof item.text !== "string")
        return;
      const text = item.text.trim();
      if (text && !translatedById.has(item.id)) {
        translatedById.set(item.id, text);
      }
    });
  }

  return sourceSegments.map((segment) => ({
    id: segment.id,
    text: translatedById.get(segment.id) || "",
    error: translatedById.has(segment.id) ? "" : "Translation unavailable.",
  }));
}

function updateTranslatedRow(segment, index, alignedItem, generation) {
  if (generation !== translationGeneration) return;
  const row = document.querySelector(
    `.transcript-entry[data-segment-id="${CSS.escape(segment.id)}"]`,
  );
  if (!row) return;

  if (alignedItem.text) {
    transcriptParagraphCache.set(
      transcriptTranslationCacheKey(segment),
      alignedItem.text,
    );
  }

  const copy = row.querySelector(".transcript-copy");
  if (copy) {
    copy.outerHTML = renderTranscriptSegmentContent(
      segment,
      currentTranscriptMode,
      alignedItem.text,
      alignedItem.error,
    );
  }
  row.classList.toggle("translated", !!alignedItem.text);
  row.classList.toggle("translating", false);
  row.classList.toggle("translation-failed", !alignedItem.text);

  const retry = row.querySelector(".translation-retry-btn");
  if (retry) {
    ["mousedown", "mouseup"].forEach((eventName) => {
      retry.addEventListener(eventName, (event) => {
        event.preventDefault();
        event.stopPropagation();
      });
    });
    retry.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      retryTranslationSegment(index, generation);
    });
  }
}

let activeTranslationQueue = null;

async function requestTranscriptTranslationBatch(
  indices,
  segments,
  generation,
  videoId,
  mode,
) {
  const sourceBatch = indices.map((index) => segments[index]);
  setTranslatingSpinner(true);
  try {
    const result = await sendTranslationMessage({
      action: "translateContent",
      content: {
        segments: sourceBatch.map(({ id, text }) => ({ id, text })),
      },
      contentType: "transcriptBatch",
      targetLanguage: getTranscriptTargetLanguage(mode),
      videoTitle: currentVideoTitle,
    });

    const isStale =
      generation !== translationGeneration ||
      videoId !== currentVideoId ||
      mode !== currentTranscriptMode;
    if (isStale) return;

    const responseSegments = result?.success
      ? result.translatedContent?.segments
      : [];
    const aligned = alignTranslatedSegmentBatch(sourceBatch, responseSegments);
    aligned.forEach((item, batchIndex) => {
      if (!result?.success) {
        item.error = result?.error || "Translation failed.";
      }
      updateTranslatedRow(
        sourceBatch[batchIndex],
        indices[batchIndex],
        item,
        generation,
      );
    });
    await updateCache();
  } catch (error) {
    if (generation !== translationGeneration) return;
    sourceBatch.forEach((segment, batchIndex) => {
      updateTranslatedRow(
        segment,
        indices[batchIndex],
        { id: segment.id, text: "", error: error.message || "Translation failed." },
        generation,
      );
    });
  } finally {
    setTranslatingSpinner(false);
    syncTranscriptOverlay();
  }
}

function retryTranslationSegment(index, generation) {
  if (generation !== translationGeneration || !activeTranslationQueue) return;
  const row = document.querySelector(
    `.transcript-entry[data-segment-index="${index}"]`,
  );
  if (row) {
    row.classList.add("translating");
    row.classList.remove("translation-failed");
    const translation = row.querySelector(".transcript-translation");
    if (translation) {
      translation.className = "transcript-translation translation-pending";
      translation.textContent = "Retrying…";
    }
  }
  activeTranslationQueue.enqueue(index, true);
}

/**
 * Renders immediately, translates the first small batch, then observes the
 * remaining rows. Batches are sequential so the provider is never flooded.
 */
async function translateTranscript() {
  const segments = getActiveTranscriptSegments();
  if (!segments.length || currentTranscriptMode === "original") return;

  if (translationTargetMatchesSource(currentTranscriptMode)) {
    currentTranscriptMode = "original";
    updateTranscriptModeSelect();
    renderTranscript();
    return;
  }

  translationGeneration += 1;
  const generation = translationGeneration;
  const videoId = currentVideoId;
  const mode = currentTranscriptMode;
  if (transcriptScrollObserver) transcriptScrollObserver.disconnect();

  const rows = renderTranscriptModeRows(segments, mode);
  const queue = [];
  const queued = new Set();
  let processing = false;

  const processNext = async () => {
    if (processing || queue.length === 0 || generation !== translationGeneration)
      return;
    processing = true;
    const indices = queue.splice(0, 3);
    indices.forEach((index) => queued.delete(index));
    try {
      await requestTranscriptTranslationBatch(
        indices,
        segments,
        generation,
        videoId,
        mode,
      );
    } finally {
      processing = false;
      if (queue.length && generation === translationGeneration) processNext();
    }
  };

  const enqueue = (index, force = false) => {
    if (!Number.isInteger(index) || !segments[index]) return;
    const cached = transcriptParagraphCache.has(
      transcriptTranslationCacheKey(segments[index]),
    );
    if ((!force && cached) || queued.has(index)) return;
    queue.push(index);
    queued.add(index);
    // Let all entries reported in the same viewport turn collect before the
    // worker starts, producing one small contextual multi-segment request.
    Promise.resolve().then(processNext);
  };
  activeTranslationQueue = { enqueue };

  transcriptScrollObserver = new IntersectionObserver(
    (observerEntries) => {
      observerEntries
        .filter((entry) => entry.isIntersecting)
        .sort(
          (a, b) =>
            Number(a.target.dataset.segmentIndex) -
            Number(b.target.dataset.segmentIndex),
        )
        .forEach((entry) => enqueue(Number(entry.target.dataset.segmentIndex)));
    },
    {
      root: document.getElementById("contentArea"),
      rootMargin: "320px 0px",
      threshold: 0,
    },
  );

  rows.forEach((row, index) => {
    if (!row.classList.contains("translated")) transcriptScrollObserver.observe(row);
    if (index < 3) enqueue(index);
  });
}

function setTranslatingSpinner(show) {
  if (show) translationWorkCount += 1;
  else translationWorkCount = Math.max(0, translationWorkCount - 1);
  const isTranslating = translationWorkCount > 0;
  const spinner = document.getElementById("langSpinner");
  if (spinner) spinner.classList.toggle("visible", isTranslating);
}

// Pure helpers are exposed for the repository's Node tests. The extension does
// not read this object at runtime.
globalThis.__YTD_TRANSCRIPT_TESTING__ = {
  sendTranslationMessage,
  groupTranscriptEntries,
  splitOversizedThought,
  alignTranslatedSegmentBatch,
  defaultTranscriptModeForLanguage,
  getTranscriptTargetLanguage,
  translationTargetMatchesSource,
  renderSubtitleInlineMarkup,
  renderTranscriptSegmentContent,
  getCurrentTranscriptViewText,
  computeLyricProgress,
  shouldStartTranscriptParagraph,
  captionTextKey,
  captionSimilarity,
  alignTranscriptToNativeCues,
  nativeCueToTranscriptEntry,
  detectFallbackTranscriptLanguage,
};
