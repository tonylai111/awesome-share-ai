/**
 * Shared, non-secret configuration helpers.
 *
 * API keys are stored in chrome.storage.local by options.js. This file contains
 * defaults and validation only, so it is safe to publish.
 */
var YTD_SETTINGS = (() => {
  const STORAGE_KEY = "ytd_settings";
  const TRANSCRIPT_MODES = Object.freeze([
    "original",
    "zh",
    "ja",
    "bilingual-en",
    "bilingual-ja",
  ]);
  const OVERLAY_STYLES = Object.freeze(["normal", "pop"]);
  const DEFAULTS = Object.freeze({
    provider: "deepseek",
    aiApiKey: "",
    aiBaseUrl: "https://api.deepseek.com",
    aiModel: "deepseek-v4-flash",
    supadataApiKey: "",
    transcriptMode: "original",
    overlayStyle: "normal",
    subtitleSyncOffset: 0,
  });

  function isLegacyCustom(input) {
    return !!input && input.provider === "custom";
  }

  function normalizeSyncOffset(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return DEFAULTS.subtitleSyncOffset;
    return Math.round(Math.min(2, Math.max(-2, numeric)) * 10) / 10;
  }

  function normalize(input = {}) {
    return {
      provider: DEFAULTS.provider,
      aiApiKey: isLegacyCustom(input)
        ? ""
        : typeof input.aiApiKey === "string"
          ? input.aiApiKey.trim()
          : "",
      aiBaseUrl: DEFAULTS.aiBaseUrl,
      aiModel: DEFAULTS.aiModel,
      supadataApiKey:
        typeof input.supadataApiKey === "string"
          ? input.supadataApiKey.trim()
          : "",
      transcriptMode: TRANSCRIPT_MODES.includes(input.transcriptMode)
        ? input.transcriptMode
        : DEFAULTS.transcriptMode,
      overlayStyle: OVERLAY_STYLES.includes(input.overlayStyle)
        ? input.overlayStyle
        : DEFAULTS.overlayStyle,
      subtitleSyncOffset: normalizeSyncOffset(input.subtitleSyncOffset),
    };
  }

  function migrateLegacyCustom(input = {}) {
    return {
      settings: normalize(input),
      migrated: isLegacyCustom(input),
    };
  }

  function chatCompletionsUrl() {
    return `${DEFAULTS.aiBaseUrl}/chat/completions`;
  }

  function canonicalYouTubeUrl(videoId) {
    const normalized = String(videoId || "").trim();
    if (!/^[A-Za-z0-9_-]{6,20}$/.test(normalized)) {
      throw new Error("Invalid YouTube video ID.");
    }
    return `https://www.youtube.com/watch?v=${normalized}`;
  }

  return {
    STORAGE_KEY,
    DEFAULTS,
    TRANSCRIPT_MODES,
    OVERLAY_STYLES,
    isLegacyCustom,
    normalize,
    migrateLegacyCustom,
    chatCompletionsUrl,
    canonicalYouTubeUrl,
  };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = YTD_SETTINGS;
}
