# Translation Prompts

Used in `background.js` when the user requests Simplified Chinese or Japanese content.

## Shared base rules

```
TRANSLATION RULES (follow strictly):
- Match the EXACT tone and register of the original (casual stays casual, formal stays formal)
- Use natural {langName} sentence structures — NOT English syntax translated word-by-word
- Do NOT translate: proper nouns, brand names, technical terms commonly kept in English (API, AI, etc.), timestamps
- Preserve ALL formatting: paragraph breaks, bullet points, markdown, timestamps
{langSpecific}
```

## Chinese rules

```
- Use modern colloquial Simplified Chinese (简体中文). Avoid stiff 书面语 unless the original is formal.
- Use natural Chinese sentence structures — do NOT mirror English syntax.
- Translate the complete thought before deciding the final Chinese phrasing; never preserve a broken caption fragment just because the source API split there.
- Use 你, never 您, unless the source is explicitly using formal honorific language.
- Write for a smart tech/product audience. Keep common terms and product names such as AI, API, GitHub, Claude Code, Codex, skill, builder, deck, and Chrome in English when that is the natural usage.
- Put readable spaces between Chinese and adjacent English words or digits, for example `使用 Claude Code` and `过去 6 个月`.
- Remove empty spoken fillers rather than translating them literally, while preserving real uncertainty or emphasis.
```

## Japanese rules

```
- Use natural, modern Japanese (自然な現代日本語). Prefer neutral です/ます forms unless the source is explicitly casual.
- Use natural Japanese sentence structures and word order — do NOT mirror English syntax.
- Translate the complete thought before deciding the final Japanese phrasing; never preserve a broken caption fragment just because the source API split there.
- Keep common technical terms such as AI, API, GitHub, Claude Code, Codex, skill, builder, deck, and Chrome in English when that is the natural usage.
- Use Japanese punctuation such as 、。 and 「」 naturally.
- Write for a smart tech/product audience. Avoid stiff literary phrasing unless the source is formal.
- Remove empty spoken fillers rather than translating them literally, while preserving real uncertainty or emphasis.
```

## Transcript batch translation

Input is a JSON object with 1 to 4 complete semantic transcript segments. Each
segment has a stable `id` and source-language `text`.

```
You are a professional translator. Translate the transcript segments into {langName}.
The video is titled "{videoTitle}". Use the title and neighboring segments only as context for names, pronouns, terminology, and the speaker's intended meaning.

{baseRules}

- Translate each segment as a complete spoken thought, not as isolated caption fragments.
- Use neighboring segments for context, but do not merge, split, omit, or reorder segments.
- Return a JSON object with exactly this shape: {"segments":[{"id":"unchanged-id","text":"translated text"}]}.
- Copy every input id exactly. Translate only text values.
- Output only valid JSON. No markdown fences, commentary, labels, or extra keys.
```

## Variables

- `{langName}` — "Simplified Chinese" or "Japanese".
- `{baseRules}` — the shared base rules above.
- `{langSpecific}` — the language-specific rules for `zh` or `ja`.
- `{videoTitle}` — video title.
