/**
 * CONTENT SCRIPT
 *
 * This script runs ON the YouTube page itself. It can see and modify
 * the YouTube page DOM (the HTML elements).
 *
 * It handles:
 * 1. Extracting video info (title, channel name) from the page
 * 2. Injecting "key moment" markers onto YouTube's progress bar
 * 3. Adding a "Digest" button to YouTube's action bar (next to Share/Save)
 *
 * Think of it like a robot sitting inside the YouTube tab,
 * reading the page and making small visual changes.
 */

const DEBUG = false;
const debugLog = (...args) => {
  if (DEBUG) console.log(...args);
};

// ============================================================
// GLOBAL STATE
// ============================================================

let ytdNoteButton = null;
let ytdNoteButtonTimer = null;
let ytdNoteKeyboardListenerAdded = false;
let ytdNoteButtonRetryTimer = null;
let ytdDigestButton = null;
let digestButtonObserver = null;
let digestButtonReconcileTimer = null;
let digestButtonResizeListenerAdded = false;
let transcriptOverlayMode = "side";
let transcriptOverlayLines = [];
let transcriptOverlayCues = [];
let renderedOverlayKey = "";
let transcriptOverlayStyle = "normal";
let transcriptOverlayOffset = 0;
let transcriptOverlayContainer = null;
let transcriptOverlayVideoElement = null;
let transcriptOverlayVideoListener = null;
let transcriptOverlayPlaybackInterval = null;
let transcriptOverlayCueListener = null;
let transcriptOverlayManualPosition = null;
let transcriptOverlayDragging = false;
let transcriptOverlayDragOffset = { x: 0, y: 0 };

// ============================================================
// INITIALIZATION
// ============================================================

/**
 * When the page loads, inject our Digest button and Note button.
 * We wait a bit for YouTube's UI to fully render.
 */
function init() {
  // Register the global "n" and "c" keyboard shortcuts once
  if (!ytdNoteKeyboardListenerAdded) {
    document.addEventListener("keydown", handleNoteKeyboardShortcut);
    ytdNoteKeyboardListenerAdded = true;
  }

  // Try to inject the buttons immediately
  injectDigestButton();
  tryInjectNoteButton();

  // Also set up an observer to handle YouTube's dynamic content loading
  // (YouTube is an SPA, so elements appear/disappear as you navigate)
  setupButtonObserver();
  setupDigestButtonResizeListener();
}

/**
 * Attempts to inject the note button. If the player container isn't ready yet,
 * retry a few times with a short delay. YouTube renders the player asynchronously
 * after navigation, so a single immediate attempt can miss it.
 */
function tryInjectNoteButton() {
  if (!window.location.pathname.includes("/watch")) return;

  // Clear any existing retry so we don't stack timers
  if (ytdNoteButtonRetryTimer) {
    clearInterval(ytdNoteButtonRetryTimer);
    ytdNoteButtonRetryTimer = null;
  }

  let attempts = 0;
  const maxAttempts = 30; // ~3 seconds of retrying

  function attempt() {
    attempts++;
    const playerContainer = document.querySelector(
      "#movie_player.html5-video-player, #movie_player, .html5-video-player",
    );

    if (playerContainer) {
      injectNoteButton();
      if (ytdNoteButtonRetryTimer) {
        clearInterval(ytdNoteButtonRetryTimer);
        ytdNoteButtonRetryTimer = null;
      }
      return;
    }

    if (attempts >= maxAttempts) {
      debugLog(
        "[YouTube Digest Content] Player container not found after retries, giving up",
      );
      if (ytdNoteButtonRetryTimer) {
        clearInterval(ytdNoteButtonRetryTimer);
        ytdNoteButtonRetryTimer = null;
      }
    }
  }

  attempt();
  if (!ytdNoteButton || !ytdNoteButton.isConnected) {
    ytdNoteButtonRetryTimer = setInterval(attempt, 100);
  }
}

// Run init when DOM is ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}

// ============================================================
// MESSAGE HANDLING
// ============================================================

/**
 * Listen for messages from the side panel or background script.
 * When they ask for video info, we read it from the page.
 * When they send key moments, we highlight them on the progress bar.
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  debugLog("[YouTube Digest Content] Received message:", message.action, message);

  if (message.action === "setTranscriptOverlay") {
    setTranscriptOverlay(
      message.mode,
      message.lines,
      message.style,
      message.syncOffset,
    );
    sendResponse({ success: true });
    return false;
  }

  if (message.action === "getNativeCaptionCues") {
    const video = document.querySelector("video.html5-main-video");
    ensureNativeTextTracks(video);
    sendResponse({ cues: collectNativeCaptionCues() });
    return false;
  }

  if (message.action === "getVideoInfo") {
    // Read video title and channel name from the page
    const info = extractVideoInfo();
    debugLog("[YouTube Digest Content] Returning video info:", info);
    sendResponse(info);
    return false; // Synchronous response
  }

  if (message.action === "highlightMoments") {
    // Key moment markers disabled — chapters are shown in the side panel only.
    sendResponse({ success: true });
    return false;
  }

  if (message.action === "getCurrentTime") {
    // Return the current video playback time (used by auto-scroll)
    const video = document.querySelector("video.html5-main-video");
    sendResponse({
      currentTime: video ? video.currentTime : 0,
      paused: video ? video.paused : true,
    });
    return false;
  }

  if (message.action === "seekTo") {
    // Jump the video to a specific timestamp
    debugLog("[YouTube Digest Content] Seeking to:", message.seconds);
    seekToTimestamp(message.seconds);
    sendResponse({ success: true });
    return false;
  }

  if (message.action === "showNoteSavedFeedback") {
    // Show brief feedback that note was saved
    showNoteSavedToast(message.note);
    sendResponse({ success: true });
    return false;
  }

  // Unknown action - still send a response to prevent hanging
  debugLog("[YouTube Digest Content] Unknown action:", message.action);
  sendResponse({ success: false, error: "Unknown action" });
  return false;
});

// ============================================================
// DIGEST BUTTON INJECTION
// ============================================================

/**
 * Injects a "Digest" button into YouTube's action bar.
 * The button appears next to Share, Save, etc. below the video.
 *
 * When clicked, it opens the YouTube Digest side panel.
 */
function isVisibleDigestHost(element) {
  if (!element || !element.isConnected) return false;

  const rect = element.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return false;

  const style = window.getComputedStyle(element);
  return style.display !== "none" && style.visibility !== "hidden";
}

/**
 * YouTube keeps hidden copies of its responsive action toolbar in the DOM.
 * querySelector() can return one of those 0x0 copies before the toolbar the
 * viewer can actually see, so inspect every candidate and resolve the native
 * button group inside the visible action row for the current video.
 */
function findDigestButtonHost() {
  const primaryActionRows = Array.from(
    document.querySelectorAll("ytd-watch-metadata #actions-inner"),
  );

  for (const actionRow of primaryActionRows) {
    if (!isVisibleDigestHost(actionRow)) continue;

    const visibleButtonGroup = Array.from(
      actionRow.querySelectorAll("#top-level-buttons-computed"),
    ).find(isVisibleDigestHost);
    if (visibleButtonGroup) return visibleButtonGroup;
  }

  const fallbackCandidates = Array.from(
    document.querySelectorAll(
      "ytd-watch-metadata #actions #top-level-buttons-computed, " +
        "ytd-watch-metadata #top-level-buttons-computed, " +
        "#primary #actions #top-level-buttons-computed",
    ),
  );

  return (
    fallbackCandidates.find(
      (candidate) =>
        isVisibleDigestHost(candidate) &&
        (candidate.closest("ytd-watch-metadata") ||
          candidate.closest("#primary")),
    ) || null
  );
}

function createDigestButton() {
  const digestButton = document.createElement("select");
  digestButton.id = "ytd-digest-button";
  digestButton.setAttribute("aria-label", "字幕模式");
  digestButton.innerHTML = `
    <option value="side">侧边栏</option>
    <option value="off">关闭</option>
    <option value="below">视频下方</option>
    <option value="above">视频上方</option>
  `;

  // Style the dropdown — flat pill in our paper-red accent, sized to sit
  // comfortably among YouTube's native action buttons.
  digestButton.style.cssText = `
    display: inline-flex;
    align-items: center;
    padding: 0 12px;
    height: 36px;
    border: none;
    border-radius: 18px;
    background: #c8674f;
    color: white;
    font-family: "Roboto", "Arial", sans-serif;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    margin-right: 8px;
    transition: background 0.2s, transform 0.1s, box-shadow 0.2s;
    box-shadow: 0 2px 8px rgba(200, 103, 79, 0.3);
    flex: 0 0 auto;
    align-self: center;
    width: max-content;
    min-width: max-content;
    max-width: max-content;
    white-space: nowrap;
  `;
  digestButton.addEventListener("change", async (event) => {
    const mode = event.target.value;
    debugLog("[YouTube Digest] Transcript mode changed:", mode);
    try {
      await chrome.storage.local.set({ ytd_overlay_mode: mode });
    } catch (error) {
      console.error("[YouTube Digest] Failed to save overlay mode:", error);
    }
    chrome.runtime.sendMessage({ action: "openSidePanel" }).catch(() => {});
    chrome.runtime
      .sendMessage({ action: "overlayModeChanged", mode })
      .catch(() => {});
  });

  ytdDigestButton = digestButton;
  return digestButton;
}

/**
 * Reconciles the Digest button with YouTube's currently visible action row.
 * This is intentionally idempotent because YouTube rebuilds its watch page
 * during navigation and at responsive breakpoints.
 */
function injectDigestButton() {
  const existingButtons = Array.from(
    document.querySelectorAll("#ytd-digest-button"),
  );

  if (!window.location.pathname.includes("/watch")) {
    existingButtons.forEach((button) => button.remove());
    ytdDigestButton = null;
    return false;
  }

  const actionsContainer = findDigestButtonHost();
  if (!actionsContainer) {
    debugLog("[YouTube Digest Content] Visible actions container not found yet");
    return false;
  }

  let digestButton = existingButtons.find(
    (button) => button === ytdDigestButton,
  );

  if (!digestButton) {
    existingButtons.forEach((button) => button.remove());
    existingButtons.length = 0;
    digestButton = createDigestButton();
  }

  existingButtons.forEach((button) => {
    if (button !== digestButton) button.remove();
  });

  if (digestButton.parentElement !== actionsContainer) {
    // YouTube turns #actions-inner into a vertical flex column at narrow
    // breakpoints. A direct child there stretches into a full-width second
    // row, so keep Digest inside the native horizontal button group and
    // prepend it to preserve visibility when space is limited.
    actionsContainer.insertBefore(digestButton, actionsContainer.firstChild);
  }

  debugLog("[YouTube Digest Content] Digest button reconciled");
  return true;
}

function scheduleDigestButtonReconciliation(delay = 80) {
  if (digestButtonReconcileTimer) {
    clearTimeout(digestButtonReconcileTimer);
  }

  digestButtonReconcileTimer = setTimeout(() => {
    digestButtonReconcileTimer = null;
    injectDigestButton();
  }, delay);
}

function setupDigestButtonResizeListener() {
  if (digestButtonResizeListenerAdded) return;

  window.addEventListener("resize", () => {
    scheduleDigestButtonReconciliation(120);
  });
  digestButtonResizeListenerAdded = true;
}

/**
 * Sets up a MutationObserver to watch for YouTube's dynamic content changes.
 * When the action buttons container appears (after navigation), we inject our button.
 */
function setupButtonObserver() {
  if (digestButtonObserver) return;

  digestButtonObserver = new MutationObserver(() => {
    // Check if we need to inject the buttons
    if (window.location.pathname.includes("/watch")) {
      scheduleDigestButtonReconciliation();
      if (!ytdNoteButton || !ytdNoteButton.isConnected) {
        tryInjectNoteButton();
      }
    }
  });

  // Watch the entire body for changes (YouTube rebuilds large chunks of the DOM)
  digestButtonObserver.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

// ============================================================
// NOTE BUTTON (Overlay on Video Player)
// ============================================================

/**
 * Injects a "Note" button overlay on top of the YouTube video player.
 * The button appears when the mouse enters or moves over the player and hides
 * after the cursor stays still for more than 2 seconds or leaves the player.
 */
function injectNoteButton() {
  // Don't inject if we're not on a video page
  if (!window.location.pathname.includes("/watch")) return;

  // Don't inject if button already exists and is properly tracked.
  // If a stale button exists (e.g., from a previous content-script instance),
  // remove it and re-inject so event listeners are attached to the live one.
  const existingButton = document.getElementById("ytd-note-button");
  if (existingButton) {
    if (ytdNoteButton === existingButton && existingButton.isConnected) {
      return; // already injected and connected
    }
    existingButton.remove();
  }

  // Find the video player container. YouTube rebuilds this dynamically, so
  // we try the most common selectors.
  const playerContainer = document.querySelector(
    "#movie_player.html5-video-player, " +
      "#movie_player, " +
      ".html5-video-player",
  );

  if (!playerContainer) {
    debugLog(
      "[YouTube Digest Content] Player container not found yet, will retry",
    );
    return;
  }

  // Ensure the player container has relative positioning for absolute children
  if (
    window.getComputedStyle(playerContainer).position === "static" ||
    !playerContainer.style.position
  ) {
    playerContainer.style.position = "relative";
  }

  debugLog("[YouTube Digest Content] Injecting note button");

  // Create the note button — a soft rounded pill that floats over the player
  const noteButton = document.createElement("button");
  noteButton.id = "ytd-note-button";
  noteButton.innerHTML = `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" style="margin-right: 7px;">
      <path d="M12 20h9"></path>
      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
    </svg>
    <span>Note</span>
  `;

  // Soft rounded pill in the terracotta accent, with a gentle shadow.
  // Start hidden; visibility is controlled by mouse activity.
  noteButton.style.cssText = `
    position: absolute;
    top: 16px;
    right: 16px;
    z-index: 9999;
    display: flex;
    align-items: center;
    padding: 9px 16px;
    background: #c8674f;
    color: white;
    border: none;
    border-radius: 999px;
    font-family: system-ui, -apple-system, "Roboto", sans-serif;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.2px;
    cursor: pointer;
    transition: opacity 0.18s ease, transform 0.18s ease, background 0.18s ease, box-shadow 0.18s ease;
    opacity: 0;
    pointer-events: none;
    box-shadow: 0 4px 14px rgba(0,0,0,0.3);
  `;

  ytdNoteButton = noteButton;

  // Show button when mouse enters or moves over the player.
  // Hide after 2 seconds of idle or when the mouse leaves.
  playerContainer.addEventListener("mouseenter", () => {
    showNoteButton();
    resetNoteButtonTimer();
  });

  playerContainer.addEventListener("mousemove", () => {
    showNoteButton();
    resetNoteButtonTimer();
  });

  playerContainer.addEventListener("mouseleave", () => {
    clearTimeout(ytdNoteButtonTimer);
    ytdNoteButtonTimer = null;
    hideNoteButton();
  });

  // Hover effect — lift slightly
  noteButton.addEventListener("mouseenter", () => {
    noteButton.style.background = "#b25742";
    noteButton.style.boxShadow = "0 6px 18px rgba(0,0,0,0.35)";
    noteButton.style.transform = "translateY(-1px)";
  });

  noteButton.addEventListener("mouseleave", () => {
    noteButton.style.background = "#c8674f";
    noteButton.style.boxShadow = "0 4px 14px rgba(0,0,0,0.3)";
    noteButton.style.transform = "translateY(0)";
  });

  // Click handler — save the current moment as a note
  noteButton.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();
    await saveCurrentNote();
  });

  playerContainer.appendChild(noteButton);

  debugLog("[YouTube Digest Content] Note button injected");
}

function showNoteButton() {
  if (!ytdNoteButton) return;
  ytdNoteButton.style.opacity = "1";
  ytdNoteButton.style.pointerEvents = "auto";
}

function hideNoteButton() {
  if (!ytdNoteButton) return;
  ytdNoteButton.style.opacity = "0";
  ytdNoteButton.style.pointerEvents = "none";
}

function resetNoteButtonTimer() {
  clearTimeout(ytdNoteButtonTimer);
  ytdNoteButtonTimer = setTimeout(() => {
    hideNoteButton();
  }, 2000);
}

/**
 * Handles the "n" and "c" keyboard shortcuts for saving notes.
 * Only triggers on YouTube watch pages and when the user is not typing
 * in an input field.
 */
function handleNoteKeyboardShortcut(e) {
  if (!window.location.pathname.includes("/watch")) return;
  const isTextNote = e.key === "n" || e.key === "N";
  const isFrameNote = e.key === "c" || e.key === "C";
  if (!isTextNote && !isFrameNote) return;

  // Ignore if the user is typing in an input/textarea/contenteditable
  const active = document.activeElement;
  if (
    active &&
    (active.tagName === "INPUT" ||
      active.tagName === "TEXTAREA" ||
      active.isContentEditable)
  ) {
    return;
  }

  // Prevent YouTube's own keyboard shortcuts while saving a Digest note.
  e.preventDefault();
  e.stopPropagation();

  // Show brief visual feedback on the button, then save
  showNoteButton();
  resetNoteButtonTimer();
  if (isFrameNote) {
    saveCurrentFrameNote();
  } else {
    saveCurrentNote();
  }
}

/**
 * Captures the current timestamp and saves it as a note.
 */
async function saveCurrentNote() {
  debugLog("[YouTube Digest] Saving note");

  const video = document.querySelector("video.html5-main-video");
  if (!video) {
    console.error("[YouTube Digest] No video element found");
    return;
  }

  // Go back 3 seconds to capture what was just said (user reacts after hearing it)
  const currentTime = Math.max(0, Math.floor(video.currentTime) - 3);
  const videoInfo = extractVideoInfo();
  const videoId = new URLSearchParams(window.location.search).get("v");

  const noteButton = ytdNoteButton;
  const originalContent = noteButton ? noteButton.innerHTML : "";

  if (noteButton) {
    noteButton.innerHTML =
      '<span style="letter-spacing: 0.2px;">SAVING...</span>';
    noteButton.style.pointerEvents = "none";
  }
  document.documentElement.dataset.ytdFrameSave = "saving";

  try {
    const result = await chrome.runtime.sendMessage({
      action: "saveNote",
      videoId: videoId,
      timestamp: currentTime,
      videoTitle: videoInfo.title,
      channelName: videoInfo.channelName,
    });

    if (result.success) {
      document.documentElement.dataset.ytdFrameSave = "ok";
      if (noteButton) {
        noteButton.innerHTML =
          '<span style="letter-spacing: 0.2px;">SAVED</span>';
        noteButton.style.background = "#7c8b6f";
      }
      showNoteSavedToast(result.note);
    } else {
      document.documentElement.dataset.ytdFrameSave = `error:${result.error}`;
      if (noteButton) {
        noteButton.innerHTML =
          '<span style="letter-spacing: 0.2px;">ERROR</span>';
      }
      console.error("[YouTube Digest] Save note error:", result.error);
    }
  } catch (err) {
    document.documentElement.dataset.ytdFrameSave = `error:${err.message}`;
    if (noteButton) {
      noteButton.innerHTML =
        '<span style="letter-spacing: 0.2px;">ERROR</span>';
    }
    console.error("[YouTube Digest] Save note exception:", err);
  }

  setTimeout(() => {
    if (noteButton) {
      noteButton.innerHTML = originalContent;
      noteButton.style.background = "#c8674f";
      noteButton.style.pointerEvents = "auto";
    }
  }, 2000);
}

function captureVideoCanvasDataUrl(video) {
  try {
    if (!video.videoWidth || !video.videoHeight) return null;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext("2d");
    context.drawImage(video, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.85);
  } catch (error) {
    debugLog("[YouTube Digest] Canvas frame capture unavailable:", error.message);
    return null;
  }
}

/**
 * Records a short cross-origin video frame through captureStream, then draws
 * the same-origin blob back to canvas. This avoids both canvas taint and the
 * activeTab screenshot permission.
 */
function captureVideoFrameWithMediaRecorder(video) {
  return new Promise((resolve) => {
    try {
      if (
        typeof video.captureStream !== "function" ||
        typeof MediaRecorder === "undefined"
      ) {
        resolve(null);
        return;
      }

      const stream = video.captureStream();
      const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp8")
        ? "video/webm;codecs=vp8"
        : "video/webm";
      const recorder = new MediaRecorder(stream, { mimeType });
      const chunks = [];
      let settled = false;
      const wasPaused = video.paused;
      const originalTime = video.currentTime;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        if (recorder.state !== "inactive") {
          try {
            recorder.stop();
          } catch (_error) {}
        }
        resolve(value);
      };
      const stopAndRestorePlayback = () => {
        if (recorder.state !== "inactive") {
          try {
            recorder.stop();
          } catch (_error) {}
        }
        if (wasPaused) {
          video.pause();
          video.currentTime = originalTime;
        }
      };
      const startRecorder = () => {
        recorder.start();
        setTimeout(stopAndRestorePlayback, 400);
      };

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size) chunks.push(event.data);
      };
      recorder.onerror = () => finish(null);
      recorder.onstop = async () => {
        try {
          const blob = new Blob(chunks, { type: "video/webm" });
          const url = URL.createObjectURL(blob);
          const copy = document.createElement("video");
          copy.muted = true;
          copy.src = url;
          copy.onloadeddata = () => {
            try {
              const canvas = document.createElement("canvas");
              canvas.width = copy.videoWidth || video.videoWidth || 640;
              canvas.height = copy.videoHeight || video.videoHeight || 360;
              canvas.getContext("2d").drawImage(copy, 0, 0);
              const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
              URL.revokeObjectURL(url);
              finish(dataUrl);
            } catch (error) {
              URL.revokeObjectURL(url);
              finish(null);
            }
          };
          copy.onerror = () => {
            URL.revokeObjectURL(url);
            finish(null);
          };
        } catch (_error) {
          finish(null);
        }
      };

      if (wasPaused) {
        video.play().catch(() => {});
        setTimeout(startRecorder, 150);
      } else {
        startRecorder();
      }
    } catch (error) {
      debugLog("[YouTube Digest] MediaRecorder capture unavailable:", error.message);
      resolve(null);
    }
  });
}

async function captureVideoFrameDataUrl(video) {
  const direct = captureVideoCanvasDataUrl(video);
  if (direct) return direct;
  return captureVideoFrameWithMediaRecorder(video);
}

/**
 * Captures the current video frame and saves it as an image note.
 */
async function saveCurrentFrameNote() {
  debugLog("[YouTube Digest] Saving video frame note");

  const video = document.querySelector("video.html5-main-video");
  if (!video) {
    console.error("[YouTube Digest] No video element found");
    return;
  }

  const currentTime = Math.max(0, Math.floor(video.currentTime));
  const rect = video.getBoundingClientRect();
  const frameDataUrl = await captureVideoFrameDataUrl(video);
  const videoInfo = extractVideoInfo();
  const videoId = new URLSearchParams(window.location.search).get("v");
  const noteButton = ytdNoteButton;
  const originalContent = noteButton ? noteButton.innerHTML : "";

  if (noteButton) {
    noteButton.innerHTML =
      '<span style="letter-spacing: 0.2px;">SAVING...</span>';
    noteButton.style.pointerEvents = "none";
  }

  try {
    const result = await chrome.runtime.sendMessage({
      action: "saveFrameNote",
      videoId,
      timestamp: currentTime,
      videoTitle: videoInfo.title,
      channelName: videoInfo.channelName,
      frameDataUrl,
      rect: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
      },
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight,
      },
    });

    if (result.success) {
      if (noteButton) {
        noteButton.innerHTML =
          '<span style="letter-spacing: 0.2px;">SAVED</span>';
        noteButton.style.background = "#7c8b6f";
      }
      showNoteSavedToast(result.note);
    } else {
      if (noteButton) {
        noteButton.innerHTML =
          '<span style="letter-spacing: 0.2px;">ERROR</span>';
      }
      console.error("[YouTube Digest] Save frame note error:", result.error);
      showDigestErrorToast("Frame save failed", result.error);
    }
  } catch (err) {
    if (noteButton) {
      noteButton.innerHTML =
        '<span style="letter-spacing: 0.2px;">ERROR</span>';
    }
    console.error("[YouTube Digest] Save frame note exception:", err);
    showDigestErrorToast("Frame save failed", err.message);
  }

  setTimeout(() => {
    if (noteButton) {
      noteButton.innerHTML = originalContent;
      noteButton.style.background = "#c8674f";
      noteButton.style.pointerEvents = "auto";
    }
  }, 2000);
}

/**
 * Shows a toast notification when a note is saved.
 */
function showNoteSavedToast(note) {
  // Remove existing toast
  const existing = document.getElementById("ytd-note-toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.id = "ytd-note-toast";
  const noteContent = note.imageDataUrl
    ? `<img src="${escapeHtmlForContent(note.imageDataUrl)}" alt="Video frame" style="width:100%; max-height:220px; object-fit:contain; border-radius:10px; margin-bottom:8px; background:#f7f3ec;">`
    : "";
  toast.innerHTML = `
    <div style="font-weight: 700; margin-bottom: 6px; color: #c8674f;">📝 Note saved</div>
    <div style="font-size: 12px; color: #6b6258; margin-bottom: 8px;">${escapeHtmlForContent(note.timestamp)} — ${escapeHtmlForContent(note.videoTitle)}</div>
    ${noteContent}
    <div style="font-size: 13px; line-height: 1.55; color: #2e2a24;">"${escapeHtmlForContent(note.text)}"</div>
    <div style="margin-top: 10px; font-size: 11px;">
      <a href="${escapeHtmlForContent(note.timestampedUrl)}" style="color: #c8674f; font-weight: 600; text-decoration: none;">🔗 Copy link</a>
    </div>
  `;

  toast.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 999999;
    background: #ffffff;
    border: 1px solid #ece5d9;
    border-radius: 14px;
    padding: 16px 20px;
    max-width: 350px;
    box-shadow: 0 12px 32px rgba(50, 42, 32, 0.2);
    font-family: system-ui, -apple-system, "Roboto", sans-serif;
    animation: ytdSlideIn 0.3s ease;
  `;

  // Add animation keyframes
  const style = document.createElement("style");
  style.textContent = `
    @keyframes ytdSlideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `;
  document.head.appendChild(style);

  // Copy link handler
  toast.querySelector("a").addEventListener("click", async (e) => {
    e.preventDefault();
    try {
      await navigator.clipboard.writeText(note.timestampedUrl);
      e.target.textContent = "✓ Copied!";
    } catch (err) {
      console.error("Copy failed:", err);
    }
  });

  document.body.appendChild(toast);

  // Auto-dismiss after 5 seconds
  setTimeout(() => {
    toast.style.animation = "ytdSlideIn 0.3s ease reverse";
    setTimeout(() => toast.remove(), 300);
  }, 5000);
}

function showDigestErrorToast(title, message) {
  const existing = document.getElementById("ytd-note-toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.id = "ytd-note-toast";
  toast.innerHTML = `
    <div style="font-weight: 700; margin-bottom: 6px; color: #c8674f;">${escapeHtmlForContent(title)}</div>
    <div style="font-size: 13px; line-height: 1.55; color: #2e2a24;">${escapeHtmlForContent(message)}</div>
  `;
  toast.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 999999;
    background: #ffffff;
    border: 1px solid #ece5d9;
    border-radius: 14px;
    padding: 16px 20px;
    max-width: 350px;
    box-shadow: 0 12px 32px rgba(50, 42, 32, 0.2);
    font-family: system-ui, -apple-system, "Roboto", sans-serif;
    animation: ytdSlideIn 0.3s ease;
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = "ytdSlideIn 0.3s ease reverse";
    setTimeout(() => toast.remove(), 300);
  }, 6000);
}

// ============================================================
// TRANSCRIPT OVERLAY (below / above the video)
// ============================================================

function ensureNativeTextTracks(video) {
  if (!video || !video.textTracks) return;
  for (const track of Array.from(video.textTracks || [])) {
    if (
      (track.kind === "captions" || track.kind === "subtitles") &&
      track.mode === "disabled"
    ) {
      try {
        track.mode = "hidden";
      } catch (_error) {
        // YouTube may briefly lock track modes during player setup.
      }
    }
  }
}

function collectNativeCaptionCues() {
  const video = document.querySelector("video.html5-main-video");
  if (!video) return [];
  ensureNativeTextTracks(video);
  const cues = [];
  for (const track of Array.from(video.textTracks || [])) {
    if (track.kind !== "captions" && track.kind !== "subtitles") continue;
    for (const cue of Array.from(track.cues || [])) {
      const text = String(cue.text || "").trim();
      if (!text) continue;
      cues.push({
        start: Number(cue.startTime) || 0,
        end: Number(cue.endTime) || (Number(cue.startTime) || 0) + 0.5,
        text,
      });
    }
  }
  cues.sort((a, b) => a.start - b.start || a.end - b.end);
  return cues;
}

function getActiveNativeCueText(video) {
  if (!video || !video.textTracks) return "";
  const time = video.currentTime;
  for (const track of Array.from(video.textTracks)) {
    for (const cue of Array.from(track.cues || [])) {
      if (time >= Number(cue.startTime) && time < Number(cue.endTime)) {
        return String(cue.text || "").trim();
      }
    }
  }
  return "";
}

function attachTranscriptOverlayCueListener(video) {
  if (!video || !video.textTracks) return;
  ensureNativeTextTracks(video);
  transcriptOverlayCueListener = () => {
    updateTranscriptOverlayPlayback();
    chrome.runtime
      .sendMessage({
        action: "nativeCueChanged",
        currentTime: video.currentTime,
        text: getActiveNativeCueText(video),
      })
      .catch(() => {});
  };
  for (const track of Array.from(video.textTracks)) {
    if (track.kind === "captions" || track.kind === "subtitles") {
      track.addEventListener("cuechange", transcriptOverlayCueListener);
    }
  }
}

function removeTranscriptOverlay() {
  transcriptOverlayContainer?.remove();
  transcriptOverlayContainer = null;
  const video = transcriptOverlayVideoElement || document.querySelector(
    "video.html5-main-video",
  );
  if (transcriptOverlayVideoListener) {
    video?.removeEventListener("timeupdate", transcriptOverlayVideoListener);
    transcriptOverlayVideoListener = null;
  }
  if (transcriptOverlayPlaybackInterval) {
    clearInterval(transcriptOverlayPlaybackInterval);
    transcriptOverlayPlaybackInterval = null;
  }
  if (transcriptOverlayCueListener) {
    for (const track of video?.textTracks || []) {
      track.removeEventListener("cuechange", transcriptOverlayCueListener);
    }
    transcriptOverlayCueListener = null;
  }
  transcriptOverlayVideoElement = null;
  document.removeEventListener("scroll", positionTranscriptOverlay, true);
  window.removeEventListener("resize", positionTranscriptOverlay);
}


function injectTranscriptOverlayStyles() {
  if (document.getElementById("ytd-overlay-style")) return;
  const style = document.createElement("style");
  style.id = "ytd-overlay-style";
  style.textContent = `
    #ytd-transcript-overlay {
      font-family: Impact, "Arial Black", "Haettenschweiler",
        "Noto Sans CJK SC", "Source Han Sans CN", "Hiragino Kaku Gothic ProN", "Hiragino Sans", "PingFang SC",
        "Microsoft YaHei", system-ui, sans-serif;
      font-weight: 900;
      letter-spacing: 0;
      text-transform: uppercase;
    }
    #ytd-transcript-overlay .ytd-overlay-window-line {
      position: relative;
      margin: 0 auto;
      text-align: center;
      white-space: nowrap;
    }
    #ytd-transcript-overlay .ytd-overlay-window-line.ytd-overlay-pop {
      animation: ytdOverlayPop 0.38s cubic-bezier(0.18, 1.62, 0.3, 1) both;
      transform-origin: 50% 72%;
    }
    @keyframes ytdOverlayPop {
      0% { transform: scale(0.42) rotate(-3deg); opacity: 0; }
      55% { transform: scale(1.22) rotate(1.2deg); opacity: 1; }
      72% { transform: scale(0.94) rotate(-0.6deg); opacity: 1; }
      100% { transform: scale(1) rotate(0deg); opacity: 1; }
    }
    #ytd-transcript-overlay .ytd-overlay-primary,
    #ytd-transcript-overlay .ytd-overlay-secondary {
      display: block;
      line-height: 1.18;
      text-align: center;
      white-space: nowrap;
      -webkit-text-stroke: 3px #000000;
      text-shadow:
        5px 0 0 #000000,
        -5px 0 0 #000000,
        0 5px 0 #000000,
        0 -5px 0 #000000,
        4px 4px 0 #000000,
        -4px 4px 0 #000000,
        4px -4px 0 #000000,
        -4px -4px 0 #000000,
        0 9px 0 rgba(0, 0, 0, 0.92),
        0 18px 32px rgba(0, 0, 0, 0.9),
        0 4px 14px rgba(0, 0, 0, 0.8);
    }
    #ytd-transcript-overlay .ytd-overlay-secondary {
      margin-top: 8px;
      -webkit-text-stroke: 2px #000000;
      opacity: 0.97;
    }
    #ytd-transcript-overlay span.ytd-overlay-spoken {
      font-weight: 900;
      opacity: 1;
      filter: saturate(1.4) brightness(1.2);
    }
    #ytd-transcript-overlay span.ytd-overlay-pending {
      font-weight: 800;
      opacity: 0.48;
      filter: saturate(0.7) brightness(0.8);
    }
    #ytd-transcript-overlay[data-overlay-style="normal"] .ytd-overlay-window-line {
      animation: none;
      white-space: normal;
    }
    #ytd-transcript-overlay[data-overlay-style="normal"] .ytd-overlay-primary,
    #ytd-transcript-overlay[data-overlay-style="normal"] .ytd-overlay-secondary {
      -webkit-text-stroke: 0px;
      text-shadow: none;
      opacity: 1;
    }
  `;
  document.head.appendChild(style);
}

function ensureTranscriptOverlay() {
  if (transcriptOverlayContainer) return transcriptOverlayContainer;
  const container = document.createElement("div");
  container.id = "ytd-transcript-overlay";
  container.setAttribute("data-mode", transcriptOverlayMode);
  container.setAttribute("data-overlay-style", transcriptOverlayStyle);
  container.style.cssText = `
    position: fixed;
    z-index: 999999;
    width: min(900px, calc(100vw - 40px));
    background: transparent;
    color: #ffffff;
    border: none;
    padding: 0;
    font-family: Impact, "Arial Black", "Haettenschweiler",
      "Noto Sans CJK SC", "Source Han Sans CN", "Hiragino Kaku Gothic ProN", "Hiragino Sans", "PingFang SC",
      "Microsoft YaHei", system-ui, sans-serif;
    font-size: 60px;
    line-height: 1.18;
    text-align: center;
    letter-spacing: 0;
    text-transform: uppercase;
    pointer-events: auto;
    cursor: move;
    user-select: none;
  `;
  document.body.appendChild(container);
  injectTranscriptOverlayStyles();
  container.addEventListener("mousedown", startTranscriptOverlayDrag);
  document.addEventListener("mousemove", moveTranscriptOverlayDrag);
  document.addEventListener("mouseup", endTranscriptOverlayDrag);
  transcriptOverlayContainer = container;
  return container;
}

function renderTranscriptOverlayWindow() {
  const container = ensureTranscriptOverlay();
  container.innerHTML = "";
  ["previous", "current", "next"].forEach((slot) => {
    const line = document.createElement("div");
    line.id = `ytd-overlay-${slot}`;
    line.className = "ytd-overlay-window-line";
    line.style.cssText = `
      color: #ffffff;
      font-size: inherit;
      font-weight: 900;
      line-height: 1.3;
      white-space: nowrap;
      word-break: break-word;
    `;
    container.appendChild(line);
  });
}

function positionTranscriptOverlay() {
  if (!transcriptOverlayContainer) return;
  if (transcriptOverlayManualPosition) {
    transcriptOverlayContainer.style.left = `${transcriptOverlayManualPosition.left}px`;
    transcriptOverlayContainer.style.top = `${transcriptOverlayManualPosition.top}px`;
    transcriptOverlayContainer.style.bottom = "auto";
    return;
  }
  const player =
    document.querySelector("#movie_player") ||
    document.querySelector("video.html5-main-video");
  if (!player) return;
  const rect = player.getBoundingClientRect();
  const width = Math.min(900, Math.max(320, (rect.width || 640) * 0.92));
  const left = Math.max(12, rect.left + (rect.width - width) / 2);
  transcriptOverlayContainer.style.left = `${left}px`;
  transcriptOverlayContainer.style.width = `${width}px`;

  if (transcriptOverlayMode === "below") {
    if (transcriptOverlayStyle === "normal") {
      transcriptOverlayContainer.style.bottom = "140px";
    } else if ((rect.height || 720) <= 480) {
      transcriptOverlayContainer.style.bottom = "140px";
    } else {
      transcriptOverlayContainer.style.bottom = `${Math.max(140, (rect.height || 720) * 0.18)}px`;
    }
    transcriptOverlayContainer.style.top = "auto";
  } else {
    transcriptOverlayContainer.style.bottom = "auto";
    if (transcriptOverlayStyle === "normal") {
      transcriptOverlayContainer.style.top = `${Math.max(8, rect.top - 120)}px`;
    } else {
      transcriptOverlayContainer.style.top = `${Math.max(8, rect.top + Math.max(24, (rect.height || 720) * 0.1))}px`;
    }
  }
}


function tokenizeOverlayText(text) {
  const tokens = [];
  let latinBuffer = "";
  for (const char of String(text || "")) {
    const isCjk = /[\u3040-\u30ff\u3400-\u9fff]/.test(char);
    if (isCjk) {
      if (latinBuffer) {
        tokens.push(latinBuffer);
        latinBuffer = "";
      }
      tokens.push(char);
    } else {
      latinBuffer += char;
      if (/\s/.test(char)) {
        tokens.push(latinBuffer);
        latinBuffer = "";
      }
    }
  }
  if (latinBuffer) tokens.push(latinBuffer);
  return tokens;
}

const OVERLAY_CJK_RE = /[\u3040-\u30ff\u3400-\u9fff]/;
const OVERLAY_PUNCT_RE = /[。！？!?，,；;、…·—–]/;
const OVERLAY_EMPHASIS_WORDS = new Set([
  "now", "wait", "stop", "look", "watch", "go", "run", "jump", "break",
  "win", "lose", "winning", "losing", "make", "get", "take", "grab",
  "find", "buy", "sell", "build", "destroy", "explode", "save", "free",
  "secret", "money", "cash", "million", "billion", "crazy", "insane",
  "massive", "huge", "giant", "epic", "wild", "dangerous", "impossible",
  "unbelievable", "incredible", "amazing", "shocking", "fastest",
  "biggest", "best", "worst", "never", "always", "literally", "actually",
  "finally", "today", "right", "must", "need", "want", "challenge",
  "prize", "record", "world", "number", "one"
]);
const OVERLAY_EMPHASIS_CJK = [
  "最", "超", "超级", "疯狂", "惊人", "恐怖", "无敌", "炸裂", "震撼",
  "绝对", "必须", "立刻", "马上", "现在", "快", "看", "停", "赢", "输",
  "钱", "秘密", "免费", "百万", "千万", "亿", "第一", "最大", "最快",
  "最强", "太好", "爽", "燃", "惊", "神", "笑", "泪", "杀", "爆", "灭",
  "逃", "救", "拿", "抢", "给", "来", "去", "试", "变", "成", "打开",
  "关闭", "买", "卖", "建", "拆", "毁", "保存", "删除", "复制", "粘贴"
];
const OVERLAY_EMPHASIS_JA = [
  "今", "待って", "待て", "見て", "見ろ", "止まれ", "止めろ", "行け",
  "来い", "勝て", "負ける", "お金", "無料", "秘密", "絶対", "超",
  "すごい", "やばい", "最高", "最強", "一番", "一億", "百万", "千万",
  "早く", "急げ", "ダメ", "無理", "不可能", "信じられない", "壊す",
  "消す", "燃える", "泣ける", "笑える", "マジ", "マジで", "本当",
  "最悪", "最高に", "今すぐ"
];

function overlayFontSizeForText(text) {
  return /[\u3040-\u30ff\u3400-\u9fff]/.test(String(text || ""))
    ? "clamp(32px, 7.8vw, 58px)"
    : "clamp(30px, 7vw, 54px)";
}

function overlaySecondaryFontSizeForText(text) {
  return /[\u3040-\u30ff\u3400-\u9fff]/.test(String(text || ""))
    ? "clamp(24px, 5.8vw, 44px)"
    : "clamp(22px, 5.4vw, 40px)";
}

function overlayHighlightColor(token) {
  const raw = String(token || "");
  const clean = raw.replace(/[^\p{L}\p{N}]/gu, "");
  if (!clean) return "";
  if (/[0-9０-９]/.test(clean) || /\p{N}/u.test(clean)) return "#ffe600";
  const lower = clean.toLowerCase();
  if (OVERLAY_EMPHASIS_WORDS.has(lower)) return "#ffe600";
  if (["万", "百万", "千万", "亿", "億"].some((unit) => clean.includes(unit))) {
    return "#ffe600";
  }
  if (OVERLAY_EMPHASIS_CJK.some((word) => clean.includes(word))) {
    return "#3aff68";
  }
  if (OVERLAY_EMPHASIS_JA.some((word) => clean.includes(word))) {
    return "#3aff68";
  }
  return "";
}

function splitOverlayChunks(text) {
  const value = String(text || "").replace(/\s+/g, " ").trim();
  if (!value) return [];

  const totalCjk = Array.from(value).filter((char) =>
    OVERLAY_CJK_RE.test(char),
  ).length;
  let maxCjk = 8;
  if (totalCjk > 8) {
    const desiredChunks = Math.ceil(totalCjk / 6);
    const baseSize = Math.floor(totalCjk / desiredChunks);
    maxCjk = totalCjk % desiredChunks === 0 ? baseSize : baseSize + 1;
  }

  const tokens = [];
  let latinBuffer = "";
  for (const char of value) {
    if (OVERLAY_CJK_RE.test(char)) {
      if (latinBuffer) {
        tokens.push(latinBuffer.trim());
        latinBuffer = "";
      }
      tokens.push(char);
      continue;
    }
    if (/\s/.test(char)) {
      if (latinBuffer) {
        tokens.push(latinBuffer.trim());
        latinBuffer = "";
      }
      tokens.push(" ");
      continue;
    }
    if (OVERLAY_PUNCT_RE.test(char)) {
      if (latinBuffer) {
        tokens.push(latinBuffer.trim());
        latinBuffer = "";
      }
      tokens.push(char);
      continue;
    }
    latinBuffer += char;
  }
  if (latinBuffer) tokens.push(latinBuffer.trim());

  const chunks = [];
  let current = [];
  let cjkCount = 0;
  let wordCount = 0;
  let breakAfterPunctuation = false;
  const hasMeaning = () =>
    current.some((token) => /[A-Za-z0-9\u3040-\u30ff\u3400-\u9fff]/.test(token));
  const flush = () => {
    const chunk = current.join("").replace(/\s+/g, " ").trim();
    if (chunk) chunks.push(chunk);
    current = [];
    cjkCount = 0;
    wordCount = 0;
    breakAfterPunctuation = false;
  };

  for (const token of tokens) {
    if (/^\s+$/.test(token)) {
      if (
        current.length &&
        /[A-Za-z0-9]$/.test(current[current.length - 1])
      ) {
        current.push(" ");
      }
      continue;
    }
    if (OVERLAY_PUNCT_RE.test(token)) {
      if (current.length && /^\s+$/.test(current[current.length - 1])) {
        current.pop();
      }
      current.push(token);
      breakAfterPunctuation = true;
      continue;
    }
    const isCjk = OVERLAY_CJK_RE.test(token);
    const isWord = /[A-Za-z0-9]/.test(token);
    const tokenCjkLength = isCjk ? Array.from(token).length : 0;
    const wouldExceed =
      (isCjk && (cjkCount + tokenCjkLength > maxCjk || wordCount >= 3)) ||
      (isWord && (wordCount + 1 > 3 || cjkCount >= maxCjk));
    if (hasMeaning() && (breakAfterPunctuation || wouldExceed)) flush();
    current.push(token);
    cjkCount += tokenCjkLength;
    if (isWord) wordCount += 1;
    breakAfterPunctuation = false;
  }
  flush();

  return chunks.filter((chunk) =>
    /[A-Za-z0-9\u3040-\u30ff\u3400-\u9fff]/.test(chunk),
  );
}

function normalizeOverlayStyle(style) {
  return style === "pop" ? "pop" : "normal";
}

function normalizeOverlayOffset(offset) {
  const numeric = Number(offset);
  return Number.isFinite(numeric)
    ? Math.min(2, Math.max(-2, numeric))
    : 0;
}

function normalizeOverlayCaptionText(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;|&amp;|&quot;|&lt;|&gt;/g, " ")
    .replace(/[^\p{L}\p{N}\u3040-\u30ff\u3400-\u9fff]/gu, "");
}

function overlayCaptionBigrams(text) {
  const chars = Array.from(text);
  if (chars.length <= 1) return chars;
  const bigrams = [];
  for (let index = 0; index < chars.length - 1; index += 1) {
    bigrams.push(chars[index] + chars[index + 1]);
  }
  return bigrams;
}

function overlayCaptionSimilarity(left, right) {
  const a = normalizeOverlayCaptionText(left);
  const b = normalizeOverlayCaptionText(right);
  if (!a || !b) return 0;
  const setA = new Set(overlayCaptionBigrams(a));
  const setB = new Set(overlayCaptionBigrams(b));
  if (!setA.size || !setB.size) return 0;
  let overlap = 0;
  setA.forEach((bigram) => {
    if (setB.has(bigram)) overlap += 1;
  });
  return (2 * overlap) / (setA.size + setB.size);
}

function findOverlayMatchIndexByText(nativeText, items) {
  const text = String(nativeText || "").trim();
  if (!text || !Array.isArray(items) || !items.length) return -1;
  let bestIndex = -1;
  let bestScore = 0;
  items.forEach((item, index) => {
    const candidate = String(item?.original || item?.text || "");
    const score = overlayCaptionSimilarity(text, candidate);
    if (score > bestScore) {
      bestScore = score;
      bestIndex = index;
    }
  });
  return bestScore >= 0.35 ? bestIndex : -1;
}

function getOverlayTimingWindows(line) {
  const fallbackStart = Number(line?.start) || 0;
  const fallbackEnd = Math.max(
    fallbackStart + 0.2,
    Number(line?.end) || fallbackStart + 1,
  );
  if (!Array.isArray(line?.lines) || line.lines.length === 0) {
    return [
      {
        start: fallbackStart,
        end: fallbackEnd,
        text: line?.original || line?.text || "",
      },
    ];
  }
  return line.lines
    .map((sub) => {
      const start = Number(sub?.start) || fallbackStart;
      return {
        start,
        end: Math.max(start + 0.2, Number(sub?.end) || start + 0.5),
        text: String(sub?.text || ""),
      };
    })
    .sort((a, b) => a.start - b.start || a.end - b.end);
}

function distributeOverlayTextToWindows(text, windows) {
  const chunks = splitOverlayChunks(text);
  if (!chunks.length || !windows.length) return windows.map(() => "");

  const totalDuration = windows.reduce(
    (sum, window) => sum + Math.max(0.1, window.end - window.start),
    0,
  );
  const counts = windows.map(() => 0);
  let remaining = chunks.length;

  windows.forEach((window, index) => {
    if (index === windows.length - 1) {
      counts[index] = remaining;
      return;
    }
    const count = Math.round(
      chunks.length *
        (Math.max(0.1, window.end - window.start) / totalDuration),
    );
    counts[index] = Math.max(0, Math.min(remaining, count));
    remaining -= counts[index];
  });

  if (chunks.length >= windows.length) {
    const emptyIndices = counts
      .map((count, index) => (count === 0 ? index : -1))
      .filter((index) => index >= 0);
    emptyIndices.forEach((emptyIndex) => {
      const largestIndex = counts.reduce(
        (best, count, index) => (count > counts[best] ? index : best),
        0,
      );
      if (counts[largestIndex] <= 0) return;
      counts[largestIndex] -= 1;
      counts[emptyIndex] = 1;
    });
  }

  let cursor = 0;
  return counts.map((count) => {
    const part = chunks.slice(cursor, cursor + count);
    cursor += count;
    return part.join(" ");
  });
}

function buildTranscriptOverlayCues(lines) {
  const cues = [];
  (Array.isArray(lines) ? lines : []).forEach((line) => {
    const windows = getOverlayTimingWindows(line);
    const primaryText = String(line?.text || "");
    const secondaryText = String(line?.translation || "");
    const useOriginalWindows = Boolean(
      line?.original &&
        (!line?.translation || primaryText === line.original),
    );
    const primaryByWindow = useOriginalWindows
      ? windows.map((window) => window.text)
      : distributeOverlayTextToWindows(primaryText, windows);
    const secondaryByWindow = secondaryText
      ? distributeOverlayTextToWindows(secondaryText, windows)
      : windows.map(() => "");

    windows.forEach((window, index) => {
      const primaryChunks = splitOverlayChunks(primaryByWindow[index] || "");
      const secondaryChunks = splitOverlayChunks(
        secondaryByWindow[index] || "",
      );
      if (!primaryChunks.length && !secondaryChunks.length) return;
      const chunkCount = Math.max(
        1,
        primaryChunks.length,
        secondaryChunks.length,
      );
      const step = Math.max(0.1, window.end - window.start) / chunkCount;
      for (let chunkIndex = 0; chunkIndex < chunkCount; chunkIndex += 1) {
        cues.push({
          start: window.start + chunkIndex * step,
          end: window.start + (chunkIndex + 1) * step,
          text: primaryChunks[chunkIndex] || "",
          translation: secondaryChunks[chunkIndex] || "",
          original: window.text || "",
        });
      }
    });
  });
  return cues;
}

function applyOverlayLineProgress(lineEl, text, progress) {
  if (!lineEl) return;
  const totalChars = Math.max(1, Array.from(String(text || "")).length);
  const spokenChars = progress * totalChars;
  lineEl.querySelectorAll("span").forEach((span) => {
    const start = Number(span.dataset.start);
    const end = Number(span.dataset.end);
    const midpoint = start + (end - start) / 2;
    const isSpoken = midpoint <= spokenChars;
    span.classList.toggle("ytd-overlay-spoken", isSpoken);
    span.classList.toggle("ytd-overlay-pending", !isSpoken);
  });
}

function renderOverlayTextLine(text, className, progress, secondary = false) {
  const line = document.createElement("div");
  line.className = className;
  const value = String(text || "");
  if (!value) return line;
  line.style.cssText = `
    font-size: ${
      secondary
        ? overlaySecondaryFontSizeForText(value)
        : overlayFontSizeForText(value)
    };
    font-weight: 900;
    line-height: 1.18;
    text-align: center;
    white-space: nowrap;
    color: #ffffff;
    -webkit-text-stroke: ${secondary ? "2px" : "3px"} #000000;
    text-shadow:
      5px 0 0 #000000,
      -5px 0 0 #000000,
      0 5px 0 #000000,
      0 -5px 0 #000000,
      4px 4px 0 #000000,
      -4px 4px 0 #000000,
      4px -4px 0 #000000,
      -4px -4px 0 #000000,
      0 9px 0 rgba(0, 0, 0, 0.92),
      0 18px 32px rgba(0, 0, 0, 0.9),
      0 4px 14px rgba(0, 0, 0, 0.8);
  `;
  let consumed = 0;
  const totalChars = Math.max(1, Array.from(value).length);
  tokenizeOverlayText(value).forEach((token) => {
    const length = Math.max(1, Array.from(token).length);
    const start = consumed;
    const end = consumed + length;
    const span = document.createElement("span");
    span.textContent = token;
    span.dataset.start = String(start);
    span.dataset.end = String(end);
    span.style.color = overlayHighlightColor(token) || "#ffffff";
    span.style.webkitTextStroke = `${secondary ? 2 : 3}px #000000`;
    line.appendChild(span);
    consumed = end;
  });
  applyOverlayLineProgress(line, value, progress);
  return line;
}

function renderOverlayCurrentLine(currentEl, line, progress) {
  currentEl.innerHTML = "";
  if (!line || (!line.text && !line.translation)) return;
  if (line.text) {
    currentEl.appendChild(
      renderOverlayTextLine(line.text, "ytd-overlay-primary", progress, false),
    );
  }
  if (line.translation) {
    currentEl.appendChild(
      renderOverlayTextLine(
        line.translation,
        "ytd-overlay-secondary",
        progress,
        true,
      ),
    );
  }
}

function updateOverlayKaraokeProgress(currentEl, cue, progress) {
  applyOverlayLineProgress(
    currentEl.querySelector(".ytd-overlay-primary"),
    cue?.text || "",
    progress,
  );
  applyOverlayLineProgress(
    currentEl.querySelector(".ytd-overlay-secondary"),
    cue?.translation || "",
    progress,
  );
}



function renderNormalOverlayCurrentLine(currentEl, line, progress) {
  currentEl.innerHTML = "";
  if (!line) return;
  currentEl.style.fontWeight = "800";
  currentEl.style.whiteSpace = "normal";

  const primary = document.createElement("div");
  primary.className = "ytd-overlay-primary";
  const text = line.text || "";
  const totalChars = Math.max(1, Array.from(text).length);
  let consumedChars = 0;
  tokenizeOverlayText(text).forEach((token) => {
    const tokenLength = Math.max(1, Array.from(token).length);
    consumedChars += tokenLength;
    const span = document.createElement("span");
    span.textContent = token;
    span.className =
      consumedChars <= progress * totalChars
        ? "ytd-overlay-spoken"
        : "ytd-overlay-pending";
    span.style.cssText = `
      color: #ffffff;
      font-size: 29px;
      line-height: 1.3;
      text-shadow:
        2px 0 0 #000000,
        -2px 0 0 #000000,
        0 2px 0 #000000,
        0 -2px 0 #000000,
        0 0 3px #000000;
    `;
    span.style.fontWeight = span.className === "ytd-overlay-spoken" ? "800" : "400";
    span.style.opacity = span.className === "ytd-overlay-spoken" ? "1" : "0.72";
    primary.appendChild(span);
  });
  currentEl.appendChild(primary);

  if (line.translation) {
    const secondary = document.createElement("div");
    secondary.className = "ytd-overlay-secondary";
    secondary.textContent = line.translation;
    secondary.style.cssText = `
      color: #ffffff;
      font-size: 25px;
      font-weight: 600;
      line-height: 1.3;
      margin-top: 4px;
      opacity: 0.95;
      text-shadow:
        2px 0 0 #000000,
        -2px 0 0 #000000,
        0 2px 0 #000000,
        0 -2px 0 #000000,
        0 0 3px #000000;
    `;
    currentEl.appendChild(secondary);
  }
}

function updateNormalTranscriptOverlayPlayback() {
  const video = document.querySelector("video.html5-main-video");
  const current = Math.max(
    0,
    (video?.currentTime || 0) + transcriptOverlayOffset,
  );
  const previousEl = document.getElementById("ytd-overlay-previous");
  const currentEl = document.getElementById("ytd-overlay-current");
  const nextEl = document.getElementById("ytd-overlay-next");
  if (!previousEl || !currentEl || !nextEl) return;

  previousEl.style.display = "none";
  nextEl.style.display = "none";
  currentEl.style.display = "block";
  currentEl.classList.remove("ytd-overlay-pop");

  const nativeText = getActiveNativeCueText(video);
  let activeIndex = findOverlayMatchIndexByText(
    nativeText,
    transcriptOverlayLines,
  );
  if (activeIndex === -1) {
    activeIndex = transcriptOverlayLines.findIndex(
      (line) => current >= Number(line.start) && current < Number(line.end),
    );
  }
  if (activeIndex === -1 && transcriptOverlayLines.length) {
    activeIndex = transcriptOverlayLines.length - 1;
  }
  if (activeIndex === -1) {
    renderNormalOverlayCurrentLine(currentEl, null, 0);
    return;
  }

  const line = transcriptOverlayLines[activeIndex];
  const duration = Math.max(0.1, Number(line.end) - Number(line.start));
  const progress = Math.min(
    1,
    Math.max(0, (current - Number(line.start)) / duration),
  );
  renderNormalOverlayCurrentLine(currentEl, line, progress);
}

function updatePopTranscriptOverlayPlayback() {
  if (!transcriptOverlayContainer) return;
  const video = document.querySelector("video.html5-main-video");
  const current = Math.max(
    0,
    (video?.currentTime || 0) + transcriptOverlayOffset,
  );
  const previousEl = document.getElementById("ytd-overlay-previous");
  const currentEl = document.getElementById("ytd-overlay-current");
  const nextEl = document.getElementById("ytd-overlay-next");
  if (!previousEl || !currentEl || !nextEl) return;

  previousEl.style.display = "none";
  nextEl.style.display = "none";
  currentEl.style.display = "block";

  const nativeText = getActiveNativeCueText(video);
  let cueIndex = findOverlayMatchIndexByText(
    nativeText,
    transcriptOverlayCues,
  );
  if (cueIndex === -1) {
    cueIndex = transcriptOverlayCues.findIndex(
      (cue) => current >= Number(cue.start) && current < Number(cue.end),
    );
  }
  if (cueIndex === -1 && transcriptOverlayCues.length) {
    cueIndex =
      current < Number(transcriptOverlayCues[0].start)
        ? 0
        : transcriptOverlayCues.length - 1;
  }
  if (cueIndex === -1) {
    if (renderedOverlayKey) {
      renderOverlayCurrentLine(currentEl, null, 0);
      currentEl.classList.remove("ytd-overlay-pop");
      renderedOverlayKey = "";
    }
    return;
  }

  const cue = transcriptOverlayCues[cueIndex];
  const duration = Math.max(0.1, Number(cue.end) - Number(cue.start));
  const progress = Math.min(
    1,
    Math.max(0, (current - Number(cue.start)) / duration),
  );
  const key = `${cueIndex}:${cue.start}:${cue.text}:${cue.translation}`;
  if (renderedOverlayKey !== key) {
    renderedOverlayKey = key;
    currentEl.classList.remove("ytd-overlay-pop");
    renderOverlayCurrentLine(currentEl, cue, progress);
    void currentEl.offsetWidth;
    currentEl.classList.add("ytd-overlay-pop");
    currentEl.style.fontWeight = "900";
    currentEl.style.whiteSpace = "nowrap";
  } else {
    updateOverlayKaraokeProgress(currentEl, cue, progress);
  }
}

function updateTranscriptOverlayPlayback() {
  if (transcriptOverlayStyle === "normal") {
    updateNormalTranscriptOverlayPlayback();
    return;
  }
  updatePopTranscriptOverlayPlayback();
}


function startTranscriptOverlayDrag(event) {
  if (!transcriptOverlayContainer) return;
  const rect = transcriptOverlayContainer.getBoundingClientRect();
  transcriptOverlayDragging = true;
  transcriptOverlayDragOffset = {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top,
  };
  event.preventDefault();
}

function moveTranscriptOverlayDrag(event) {
  if (!transcriptOverlayDragging || !transcriptOverlayContainer) return;
  const left = Math.min(
    window.innerWidth - 24,
    Math.max(8, event.clientX - transcriptOverlayDragOffset.x),
  );
  const top = Math.min(
    window.innerHeight - 24,
    Math.max(8, event.clientY - transcriptOverlayDragOffset.y),
  );
  transcriptOverlayContainer.style.left = `${left}px`;
  transcriptOverlayContainer.style.top = `${top}px`;
  transcriptOverlayContainer.style.bottom = "auto";
  transcriptOverlayManualPosition = { left, top };
}

function endTranscriptOverlayDrag() {
  if (!transcriptOverlayDragging) return;
  transcriptOverlayDragging = false;
  if (transcriptOverlayManualPosition) {
    chrome.storage.local
      .set({ ytd_overlay_position: transcriptOverlayManualPosition })
      .catch(() => {});
  }
}

function setTranscriptOverlay(mode, lines, style, syncOffset) {
  const previousMode = transcriptOverlayMode;
  transcriptOverlayStyle = normalizeOverlayStyle(style);
  transcriptOverlayOffset = normalizeOverlayOffset(syncOffset);
  transcriptOverlayMode =
    mode === "below" || mode === "above"
      ? mode
      : mode === "off"
        ? "off"
        : "side";
  if (previousMode !== transcriptOverlayMode) {
    transcriptOverlayManualPosition = null;
    chrome.storage.local
      .remove("ytd_overlay_position")
      .catch(() => {});
  }
  transcriptOverlayLines = Array.isArray(lines) ? lines : [];
  transcriptOverlayCues = buildTranscriptOverlayCues(transcriptOverlayLines);
  renderedOverlayKey = "";
  removeTranscriptOverlay();
  const video = document.querySelector("video.html5-main-video");
  transcriptOverlayVideoElement = video || null;
  if (video) {
    transcriptOverlayVideoListener = updateTranscriptOverlayPlayback;
    video.addEventListener("timeupdate", transcriptOverlayVideoListener);
    attachTranscriptOverlayCueListener(video);
  }
  if (transcriptOverlayMode === "side" || transcriptOverlayMode === "off") return;

  renderTranscriptOverlayWindow();
  positionTranscriptOverlay();
  updateTranscriptOverlayPlayback();
  chrome.storage.local
    .get("ytd_overlay_position")
    .then((stored) => {
      if (stored.ytd_overlay_position) {
        transcriptOverlayManualPosition = stored.ytd_overlay_position;
        positionTranscriptOverlay();
      }
    })
    .catch(() => {});
  transcriptOverlayPlaybackInterval = setInterval(
    updateTranscriptOverlayPlayback,
    80,
  );
  document.addEventListener("scroll", positionTranscriptOverlay, true);
  window.addEventListener("resize", positionTranscriptOverlay);
}

// ============================================================
// VIDEO INFO EXTRACTION
// ============================================================

/**
 * Reads the video title, channel name, and description directly from YouTube's page.
 * These are just sitting in the HTML — we grab them from the DOM elements.
 */
function extractVideoInfo() {
  // The video title is in an h1 element inside the #title container
  const titleElement = document.querySelector(
    "h1.ytd-watch-metadata yt-formatted-string, #title h1 yt-formatted-string",
  );

  // The channel name is in the channel info section
  const channelElement = document.querySelector(
    "#channel-name yt-formatted-string a, ytd-channel-name yt-formatted-string a",
  );

  // Video duration from the video element
  const videoElement = document.querySelector("video.html5-main-video");

  // Video description — YouTube has this in a few possible places
  const descriptionElement = document.querySelector(
    "#description-inner, " +
      "ytd-watch-metadata #description yt-attributed-string, " +
      "#description yt-formatted-string, " +
      "ytd-expander#description yt-attributed-string",
  );

  return {
    title: titleElement?.textContent?.trim() || "",
    channelName: channelElement?.textContent?.trim() || "",
    duration: videoElement?.duration || 0,
    description: descriptionElement?.textContent?.trim() || "",
  };
}

// ============================================================
// PROGRESS BAR KEY MOMENTS
// ============================================================

/**
 * Adds colored marker dots to YouTube's video progress bar
 * at the positions of key moments identified by the AI provider.
 *
 * How it works:
 * - YouTube's progress bar is a <div> element with a known class
 * - We calculate each moment's position as a percentage of total duration
 * - We inject small colored <div> elements at those positions
 * - The markers are absolutely positioned on top of the progress bar
 *
 * This is a "bonus feature" — it gives you a visual preview
 * of where the good stuff is in the video.
 */
function highlightKeyMoments(moments, videoDuration) {
  // Disabled: no timeline markers. Chapters live only in the side panel.
  return;
}

// ============================================================
// SEEK TO TIMESTAMP
// ============================================================

/**
 * Jumps the YouTube video to a specific timestamp (in seconds).
 * This is called when the user clicks a timestamp in the side panel.
 *
 * We simply set the video element's .currentTime property,
 * which is the standard HTML5 way to seek in a video.
 */
function seekToTimestamp(seconds) {
  const target = Number(seconds);
  let attempts = 0;

  function attempt() {
    const video = document.querySelector("video.html5-main-video");
    if (!video) {
      if (attempts < 20) {
        attempts += 1;
        setTimeout(attempt, 100);
        return;
      }
      console.error("[YouTube Digest Content] No video element found for seek");
      return;
    }

    debugLog("[YouTube Digest Content] Seeking to:", target);
    video.currentTime = target;
    // Also play the video if it's paused
    if (video.paused) {
      video.play().catch(() => {}); // Ignore autoplay errors
    }
  }

  attempt();
}

function escapeHtmlForContent(text) {
  const div = document.createElement("div");
  div.textContent = text || "";
  return div.innerHTML;
}

// ============================================================
// PAGE NAVIGATION DETECTION
// ============================================================

/**
 * YouTube is a "Single Page Application" (SPA). This means when you
 * click on a new video, the page doesn't fully reload — YouTube
 * dynamically swaps out the content. So our content script stays alive
 * but needs to detect when the video changes.
 *
 * We watch for URL changes using the `yt-navigate-finish` event,
 * which YouTube fires after navigation completes. When that happens,
 * we clean up old markers and re-inject the button.
 */
document.addEventListener("yt-navigate-finish", () => {
  // Clean up old key moment markers when navigating to a new video
  const existingMarkers = document.querySelectorAll(".ytd-key-moment-markers");
  existingMarkers.forEach((m) => m.remove());

  // Remove old buttons (they will be re-injected for the new video)
  document
    .querySelectorAll("#ytd-digest-button")
    .forEach((button) => button.remove());
  ytdDigestButton = null;
  if (digestButtonReconcileTimer) {
    clearTimeout(digestButtonReconcileTimer);
    digestButtonReconcileTimer = null;
  }

  const existingNoteButton = document.getElementById("ytd-note-button");
  if (existingNoteButton) existingNoteButton.remove();

  // Reset note button state
  ytdNoteButton = null;
  clearTimeout(ytdNoteButtonTimer);
  ytdNoteButtonTimer = null;
  if (ytdNoteButtonRetryTimer) {
    clearInterval(ytdNoteButtonRetryTimer);
    ytdNoteButtonRetryTimer = null;
  }

  // Remove any toasts
  const existingToast = document.getElementById("ytd-note-toast");
  if (existingToast) existingToast.remove();

  // Re-inject buttons for the new video (with a small delay for YouTube to render)
  setTimeout(() => {
    scheduleDigestButtonReconciliation(0);
    tryInjectNoteButton();
  }, 500);
});
