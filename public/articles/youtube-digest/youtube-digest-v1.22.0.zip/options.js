const YTD_OPTIONS = (() => {
  const LANGUAGE_STORAGE_KEY = "ytd_options_language";
  const PREVIEW_STORAGE_PREFIX = "youtubeDigestPreview:";
  const SUPPORTED_LANGUAGES = new Set(["en", "zh-CN", "ja"]);

  const COPY = {
    en: {
      pageTitle: "YouTube Digest Settings",
      languageGroupLabel: "Interface language",
      heading: "Bring your own API keys",
      lede:
        "Keys stay in this Chrome profile and are sent only to Supadata and DeepSeek. This open-source extension has no developer server or analytics.",
      transcriptProvider: "Transcript provider",
      transcriptLanguageTitle: "Transcript language",
      transcriptLanguageLabel: "Display mode",
      transcriptModeOriginal: "Original",
      transcriptModeZh: "中文",
      transcriptModeJa: "日本語",
      transcriptModeBilingualEn: "英语-双语",
      transcriptModeBilingualJa: "日语-双语",
      transcriptLanguageHelp:
        "Choose how transcripts appear in the side panel. Bilingual modes show the original plus the translated text.",
      overlayStyleTitle: "Video subtitle style",
      overlayStyleLabel: "Overlay style",
      overlayStyleNormal: "Normal subtitles",
      overlayStylePop: "Elastic pop subtitles",
      overlayStyleHelp:
        "Normal keeps the previous compact overlay. Elastic pop uses short punchy chunks, highlights, and a scale-up animation.",
      subtitleSyncOffsetLabel: "Sync offset (seconds)",
      subtitleSyncOffsetHelp:
        "Negative moves subtitles earlier; positive moves them later.",
      supadataApiKeyLabel: "Supadata API key",
      supadataHelp: "Used to fetch timestamped YouTube subtitles. ",
      supadataLink: "Create a Supadata account and key",
      supadataHelpSuffix:
        ". Supadata generates the key during onboarding.",
      aiProvider: "AI provider",
      providerSummaryLabel: "Supported AI provider",
      providerBadge: "Supported in this version",
      deepseekApiKeyLabel: "DeepSeek API key",
      deepseekHelp:
        "YouTube Digest uses DeepSeek V4 Flash for overviews, explanations, translation, and note polishing. ",
      deepseekLink: "Create a DeepSeek API key",
      deepseekHelpSuffix: ".",
      privacyNote:
        "When you use AI features, DeepSeek receives the video transcript and relevant video context. Review DeepSeek's terms and pricing before saving.",
      saveSettings: "Save settings",
      localRemix: "Local remix",
      customizationTitle: "Want to use another AI model?",
      customizationPurpose: "Edit and copy a safe prompt for your coding agent",
      agentBadge: "Coding agent ready",
      customizationIntro:
        "You can edit the prompt directly. Complete these three steps before copying:",
      customizationStepFolder:
        "Open the extracted YouTube Digest project folder in your coding agent.",
      customizationStepReplace:
        "Replace [PROVIDER] and [MODEL] with the service and model you want to use.",
      customizationStepKeys:
        "Never include API keys in the prompt or chat. Enter them yourself after the code is ready.",
      customizationPromptLabel: "Editable customization prompt",
      customizationReminderLabel: "Prompt reminder",
      customizationReminder:
        "Before copying, replace [PROVIDER] and [MODEL] with the provider and model you want to use.",
      customizationPrompt:
        "Customize this local YouTube Digest workspace to use [PROVIDER] with [MODEL]. Work only in the current workspace. Before editing, verify that it contains manifest.json and that the manifest name is YouTube Digest. If verification fails, stop and ask me to open the extracted YouTube Digest project folder in my coding agent. Do not search other folders, edit a guessed copy, assume an installation path, or claim Chrome can reveal the absolute OS source path. Update the provider's API endpoint, request format, and minimum Chrome host permissions. Preserve bring-your-own-key and local Chrome storage. Never put API keys in source code, commits, logs, screenshots, this prompt, or chat; after the code is ready, tell me where to enter the key myself. Keep DeepSeek-only request fields and retry behavior isolated to DeepSeek. Handle provider-specific rules separately so one provider does not affect another. Update README.md, README.zh-CN.md, PRIVACY.md, SECURITY.md, and tests. Run npm test, npm run check, and npm run package. Then explain how to reload the unpacked extension and test it on a real YouTube video.",
      copyCustomizationPrompt: "Copy edited prompt",
      localData: "Local data",
      localDataHelp:
        "Digests, translations, and notes are stored only in this Chrome profile. You can remove them at any time.",
      clearCache: "Clear cached digests",
      deleteNotes: "Delete all notes",
      resetData: "Reset extension data",
      footer:
        'Read <a href="PRIVACY.md" target="_blank">PRIVACY.md</a> in the repository for the complete data-flow description.',
      migrationWarning:
        "Custom provider settings were removed safely. Your Supadata key was kept, but the AI key was cleared. Enter a DeepSeek API key to continue.",
      saving: "Saving…",
      addSupadataKey: "Add a Supadata API key.",
      addDeepseekKey: "Add a DeepSeek API key.",
      saved: "Saved. Reopen YouTube Digest to use these settings.",
      saveFailed: "Could not save settings. Please try again.",
      copying: "Copying…",
      promptCopied: "Edited prompt copied.",
      copyFailed:
        "Could not copy the prompt. Select the prompt text and copy it manually.",
      clearedDigests: ({ count }) =>
        `Cleared ${count} cached digest${count === 1 ? "" : "s"}.`,
      notesDeleted: "Deleted all saved notes.",
      resetConfirm:
        "Delete API keys, cached digests, translations, and saved notes from this Chrome profile?",
      allDataDeleted: "All YouTube Digest data was deleted.",
      settingsLoadFailed:
        "Could not load saved settings. You can still preview this page.",
    },
    "zh-CN": {
      pageTitle: "YouTube Digest 设置",
      languageGroupLabel: "界面语言",
      heading: "使用你自己的 API 密钥",
      lede:
        "密钥仅保存在当前 Chrome 个人资料中，只会发送给 Supadata 和 DeepSeek。本开源扩展没有开发者服务器，也不使用分析服务。",
      transcriptProvider: "字幕服务",
      transcriptLanguageTitle: "字幕语言",
      transcriptLanguageLabel: "显示方式",
      transcriptModeOriginal: "原文",
      transcriptModeZh: "中文",
      transcriptModeJa: "日本語",
      transcriptModeBilingualEn: "英语-双语",
      transcriptModeBilingualJa: "日语-双语",
      transcriptLanguageHelp:
        "选择侧边栏中字幕的显示方式。双语模式会同时显示原文和译文。",
      overlayStyleTitle: "视频字幕样式",
      overlayStyleLabel: "叠加字幕样式",
      overlayStyleNormal: "正常字幕",
      overlayStylePop: "弹性弹出字幕",
      overlayStyleHelp:
        "正常模式保持上一个版本的紧凑字幕。弹性弹出模式使用极短分段、重点高亮和放大弹出动画。",
      subtitleSyncOffsetLabel: "字幕同步微调（秒）",
      subtitleSyncOffsetHelp: "负值让字幕提前，正值让字幕延后。",
      supadataApiKeyLabel: "Supadata API 密钥",
      supadataHelp: "用于获取带时间戳的 YouTube 字幕。",
      supadataLink: "创建 Supadata 账号并获取密钥",
      supadataHelpSuffix: "。Supadata 会在引导流程中生成密钥。",
      aiProvider: "AI 服务",
      providerSummaryLabel: "支持的 AI 服务",
      providerBadge: "当前版本支持",
      deepseekApiKeyLabel: "DeepSeek API 密钥",
      deepseekHelp:
        "YouTube Digest 使用 DeepSeek V4 Flash 生成概览、解释内容、翻译字幕和润色笔记。",
      deepseekLink: "创建 DeepSeek API 密钥",
      deepseekHelpSuffix: "。",
      privacyNote:
        "使用 AI 功能时，DeepSeek 会收到视频字幕及相关视频上下文。保存前请查看 DeepSeek 的服务条款和价格。",
      saveSettings: "保存设置",
      localRemix: "本地改造",
      customizationTitle: "想使用其他 AI 模型？",
      customizationPurpose: "编辑并复制一段可安全交给编程 Agent 的提示词",
      agentBadge: "可交给编程 Agent",
      customizationIntro: "你可以直接编辑提示词。复制前完成以下三步：",
      customizationStepFolder:
        "在编程 Agent 中打开 YouTube Digest 解压后的项目文件夹。",
      customizationStepReplace:
        "把 [PROVIDER] 和 [MODEL] 替换成你想使用的服务和模型。",
      customizationStepKeys:
        "不要在提示词或聊天中加入 API 密钥。代码准备好后，请自行填写。",
      customizationPromptLabel: "可编辑的自定义提示词",
      customizationReminderLabel: "提示词提醒",
      customizationReminder:
        "复制前，请先把 [PROVIDER] 和 [MODEL] 替换成你想使用的服务和模型。",
      customizationPrompt:
        "请把当前本地 YouTube Digest 工作区改为使用 [PROVIDER] 提供的 [MODEL]。只在当前工作区中操作。编辑前，先确认其中包含 manifest.json，且 manifest 中的 name 是 YouTube Digest。如果验证失败，请停止，并让我在编程 Agent 中打开 YouTube Digest 解压后的项目文件夹。不要搜索其他文件夹，不要编辑猜测的副本，不要假设安装路径，也不要声称 Chrome 可以显示操作系统中的绝对源码路径。更新该服务的 API endpoint、请求格式和最少的 Chrome host permissions。保留用户自带密钥模式和 Chrome 本地存储。不要把 API 密钥写入源代码、提交记录、日志、截图、这段提示词或聊天；代码准备好后，请告诉我应该在哪里自行填写密钥。DeepSeek 专用的请求参数和重试逻辑继续只用于 DeepSeek。新服务的专属规则请单独处理，避免相互影响。更新 README.md、README.zh-CN.md、PRIVACY.md、SECURITY.md 和测试。运行 npm test、npm run check 和 npm run package。最后，说明如何重新加载已解压的扩展，并在真实 YouTube 视频上测试。",
      copyCustomizationPrompt: "复制编辑后的提示词",
      localData: "本地数据",
      localDataHelp:
        "摘要、翻译和笔记仅保存在当前 Chrome 个人资料中。你可以随时删除。",
      clearCache: "清除缓存的摘要",
      deleteNotes: "删除全部笔记",
      resetData: "重置扩展数据",
      footer:
        '完整数据流说明请参阅仓库中的 <a href="PRIVACY.md" target="_blank">PRIVACY.md</a>。',
      migrationWarning:
        "已安全移除自定义服务设置。Supadata 密钥已保留，AI 密钥已清除。请输入 DeepSeek API 密钥以继续使用。",
      saving: "正在保存…",
      addSupadataKey: "请添加 Supadata API 密钥。",
      addDeepseekKey: "请添加 DeepSeek API 密钥。",
      saved: "已保存。请重新打开 YouTube Digest 以使用这些设置。",
      saveFailed: "无法保存设置，请重试。",
      copying: "正在复制…",
      promptCopied: "已复制编辑后的提示词。",
      copyFailed: "无法复制提示词。请选中提示词文本并手动复制。",
      clearedDigests: ({ count }) => `已清除 ${count} 条缓存摘要。`,
      notesDeleted: "已删除全部已保存的笔记。",
      resetConfirm:
        "要从当前 Chrome 个人资料中删除 API 密钥、缓存摘要、翻译和已保存的笔记吗？",
      allDataDeleted: "已删除全部 YouTube Digest 数据。",
      settingsLoadFailed: "无法加载已保存的设置，但你仍可预览此页面。",
    },
    ja: {
      pageTitle: "YouTube Digest 設定",
      languageGroupLabel: "インターフェース言語",
      heading: "自分で API キーを用意する",
      lede:
        "キーはこの Chrome プロファイルに保存され、Supadata と DeepSeek にのみ送信されます。このオープンソース拡張機能には開発者サーバーや分析機能はありません。",
      transcriptProvider: "字幕プロバイダー",
      transcriptLanguageTitle: "字幕言語",
      transcriptLanguageLabel: "表示モード",
      transcriptModeOriginal: "原文",
      transcriptModeZh: "中国語",
      transcriptModeJa: "日本語",
      transcriptModeBilingualEn: "英語-バイリンガル",
      transcriptModeBilingualJa: "日本語-バイリンガル",
      transcriptLanguageHelp:
        "サイドパネルでの字幕表示方法を選択します。バイリンガルモードでは原文と翻訳を同時に表示します。",
      overlayStyleTitle: "動画字幕スタイル",
      overlayStyleLabel: "字幕スタイル",
      overlayStyleNormal: "通常字幕",
      overlayStylePop: "弾むポップ字幕",
      overlayStyleHelp:
        "通常モードは以前のコンパクトな字幕表示です。ポップモードは短い字幕、強調色、スケールアップアニメーションを使います。",
      subtitleSyncOffsetLabel: "字幕同期微調整（秒）",
      subtitleSyncOffsetHelp:
        "負の値で字幕を早め、正の値で字幕を遅らせます。",
      supadataApiKeyLabel: "Supadata API キー",
      supadataHelp: "タイムスタンプ付きの YouTube 字幕の取得に使います。",
      supadataLink: "Supadata のアカウントとキーを作成",
      supadataHelpSuffix:
        "。Supadata はオンボーディング中にキーを生成します。",
      aiProvider: "AI プロバイダー",
      providerSummaryLabel: "対応 AI プロバイダー",
      providerBadge: "このバージョンで対応",
      deepseekApiKeyLabel: "DeepSeek API キー",
      deepseekHelp:
        "YouTube Digest は DeepSeek V4 Flash を使用して、概要、説明、翻訳、ノートの推敲を行います。",
      deepseekLink: "DeepSeek API キーを作成",
      deepseekHelpSuffix: "。",
      privacyNote:
        "AI 機能を使うと、DeepSeek に動画の字幕と関連する動画コンテキストが送信されます。保存前に DeepSeek の利用規約と料金を確認してください。",
      saveSettings: "設定を保存",
      localRemix: "ローカル改変",
      customizationTitle: "別の AI モデルを使いたい場合",
      customizationPurpose: "コーディング Agent に安全に渡せるプロンプトを編集してコピー",
      agentBadge: "コーディング Agent 対応",
      customizationIntro:
        "プロンプトを直接編集できます。コピーする前に次の 3 つの手順を完了してください:",
      customizationStepFolder:
        "コーディング Agent で解凍した YouTube Digest プロジェクトフォルダーを開いてください。",
      customizationStepReplace:
        "[PROVIDER] と [MODEL] を使いたいサービスとモデルに置き換えてください。",
      customizationStepKeys:
        "プロンプトやチャットに API キーを含めないでください。コードの準備ができたら自分で入力してください。",
      customizationPromptLabel: "編集できるカスタマイズプロンプト",
      customizationReminderLabel: "プロンプトの注意",
      customizationReminder:
        "コピーする前に、[PROVIDER] と [MODEL] を使いたいプロバイダーとモデルに置き換えてください。",
      customizationPrompt:
        "このローカルな YouTube Digest ワークスペースを、[PROVIDER] が提供する [MODEL] を使うように変更してください。現在のワークスペースだけで作業してください。編集前に manifest.json が含まれ、manifest の name が YouTube Digest であることを確認してください。検証に失敗したら停止し、コーディング Agent で YouTube Digest の解凍済みプロジェクトフォルダーを開くよう私に依頼してください。他のフォルダーを検索したり、推測したコピーを編集したり、インストールパスを仮定したり、Chrome が OS の絶対ソースパスを表示できると主張したりしないでください。プロバイダーの API エンドポイント、リクエスト形式、最小限の Chrome host permissions を更新してください。bring-your-own-key と Chrome ローカルストレージを維持してください。API キーをソースコード、コミット、ログ、スクリーンショット、このプロンプト、チャットに入れないでください。コードの準備ができたら、自分でキーを入力する場所を教えてください。DeepSeek 専用のリクエストフィールドと再試行処理は DeepSeek だけに限定してください。プロバイダー固有のルールは個別に処理し、互いに影響させないでください。README.md、README.zh-CN.md、PRIVACY.md、SECURITY.md、テストを更新してください。npm test、npm run check、npm run package を実行してください。最後に、解凍された拡張機能を再読み込みする方法と、実際の YouTube 動画でテストする方法を説明してください。",
      copyCustomizationPrompt: "編集したプロンプトをコピー",
      localData: "ローカルデータ",
      localDataHelp:
        "概要、翻訳、ノートはこの Chrome プロファイルにのみ保存されます。いつでも削除できます。",
      clearCache: "キャッシュされた概要をクリア",
      deleteNotes: "すべてのノートを削除",
      resetData: "拡張機能データをリセット",
      footer:
        '完全なデータフローはリポジトリの <a href="PRIVACY.md" target="_blank">PRIVACY.md</a> を参照してください。',
      migrationWarning:
        "カスタムプロバイダーの設定は安全に削除されました。Supadata キーは保持されましたが、AI キーはクリアされました。続行するには DeepSeek API キーを入力してください。",
      saving: "保存中…",
      addSupadataKey: "Supadata API キーを追加してください。",
      addDeepseekKey: "DeepSeek API キーを追加してください。",
      saved: "保存しました。YouTube Digest を開き直すと設定が反映されます。",
      saveFailed: "設定を保存できませんでした。もう一度お試しください。",
      copying: "コピー中…",
      promptCopied: "編集したプロンプトをコピーしました。",
      copyFailed:
        "プロンプトをコピーできませんでした。テキストを選択して手動でコピーしてください。",
      clearedDigests: ({ count }) =>
        `${count} 件のキャッシュ概要をクリアしました。`,
      notesDeleted: "保存済みのノートをすべて削除しました。",
      resetConfirm:
        "この Chrome プロファイルから API キー、キャッシュされた概要、翻訳、保存済みノートを削除しますか？",
      allDataDeleted: "すべての YouTube Digest データを削除しました。",
      settingsLoadFailed:
        "保存済み設定を読み込めませんでした。このページのプレビューは引き続き利用できます。",
    },
  };

  function normalizeLanguage(language) {
    return SUPPORTED_LANGUAGES.has(language) ? language : "en";
  }

  function translate(language, key, params = {}) {
    const normalizedLanguage = normalizeLanguage(language);
    const value = COPY[normalizedLanguage][key] ?? COPY.en[key] ?? "";
    return typeof value === "function" ? value(params) : value;
  }

  function createStorageAdapter(chromeApi, fallbackStorage) {
    const chromeStorage = chromeApi?.storage?.local;
    const memoryStorage = new Map();

    function fallbackKeys() {
      const keys = [];
      if (!fallbackStorage) return keys;
      try {
        for (let index = 0; index < fallbackStorage.length; index += 1) {
          const key = fallbackStorage.key(index);
          if (key?.startsWith(PREVIEW_STORAGE_PREFIX)) keys.push(key);
        }
      } catch (_error) {
        return [];
      }
      return keys;
    }

    function readFallbackValue(key) {
      try {
        const rawValue = fallbackStorage?.getItem(
          `${PREVIEW_STORAGE_PREFIX}${key}`,
        );
        if (rawValue !== null && rawValue !== undefined) {
          return JSON.parse(rawValue);
        }
      } catch (_error) {
        // Fall through to memory when localStorage is unavailable or malformed.
      }
      return memoryStorage.get(key);
    }

    function writeFallbackValue(key, value) {
      memoryStorage.set(key, value);
      try {
        fallbackStorage?.setItem(
          `${PREVIEW_STORAGE_PREFIX}${key}`,
          JSON.stringify(value),
        );
      } catch (_error) {
        // The in-memory copy keeps a restricted preview functional.
      }
    }

    return {
      async get(keys) {
        if (chromeStorage) return chromeStorage.get(keys);

        const requestedKeys =
          keys === null
            ? [
                ...new Set([
                  ...memoryStorage.keys(),
                  ...fallbackKeys().map((key) =>
                    key.slice(PREVIEW_STORAGE_PREFIX.length),
                  ),
                ]),
              ]
            : Array.isArray(keys)
              ? keys
              : [keys];

        return Object.fromEntries(
          requestedKeys
            .map((key) => [key, readFallbackValue(key)])
            .filter(([, value]) => value !== undefined),
        );
      },

      async set(items) {
        if (chromeStorage) return chromeStorage.set(items);
        for (const [key, value] of Object.entries(items)) {
          writeFallbackValue(key, value);
        }
      },

      async remove(keys) {
        if (chromeStorage) return chromeStorage.remove(keys);
        for (const key of Array.isArray(keys) ? keys : [keys]) {
          memoryStorage.delete(key);
          try {
            fallbackStorage?.removeItem(`${PREVIEW_STORAGE_PREFIX}${key}`);
          } catch (_error) {
            // Memory removal is sufficient for this preview session.
          }
        }
      },

      async clear() {
        if (chromeStorage) return chromeStorage.clear();
        memoryStorage.clear();
        for (const key of fallbackKeys()) {
          try {
            fallbackStorage.removeItem(key);
          } catch (_error) {
            // Continue clearing any remaining preview keys.
          }
        }
      },
    };
  }

  async function readPreferredLanguage(storage) {
    const stored = await storage.get(LANGUAGE_STORAGE_KEY);
    return normalizeLanguage(stored[LANGUAGE_STORAGE_KEY]);
  }

  async function persistPreferredLanguage(storage, language) {
    const normalizedLanguage = normalizeLanguage(language);
    await storage.set({ [LANGUAGE_STORAGE_KEY]: normalizedLanguage });
    return normalizedLanguage;
  }

  function updateLanguageButtonState(buttons, language) {
    const normalizedLanguage = normalizeLanguage(language);
    for (const button of buttons) {
      button.setAttribute(
        "aria-pressed",
        String(button.dataset.language === normalizedLanguage),
      );
    }
  }

  function updateLocalizedPrompt(textarea, prompt) {
    const selectionStart = textarea.selectionStart;
    const selectionEnd = textarea.selectionEnd;
    const selectionDirection = textarea.selectionDirection;
    const scrollTop = textarea.scrollTop;
    const scrollLeft = textarea.scrollLeft;

    textarea.value = prompt;

    if (
      Number.isInteger(selectionStart) &&
      Number.isInteger(selectionEnd) &&
      typeof textarea.setSelectionRange === "function"
    ) {
      textarea.setSelectionRange(
        Math.min(selectionStart, prompt.length),
        Math.min(selectionEnd, prompt.length),
        selectionDirection || "none",
      );
    }
    textarea.scrollTop = scrollTop;
    textarea.scrollLeft = scrollLeft;
  }

  function createPromptDrafts() {
    return {
      en: translate("en", "customizationPrompt"),
      "zh-CN": translate("zh-CN", "customizationPrompt"),
      ja: translate("ja", "customizationPrompt"),
    };
  }

  function switchPromptDraft(
    drafts,
    currentLanguage,
    nextLanguage,
    currentValue,
  ) {
    const normalizedCurrentLanguage = normalizeLanguage(currentLanguage);
    const normalizedNextLanguage = normalizeLanguage(nextLanguage);
    drafts[normalizedCurrentLanguage] = String(currentValue ?? "");
    if (typeof drafts[normalizedNextLanguage] !== "string") {
      drafts[normalizedNextLanguage] = translate(
        normalizedNextLanguage,
        "customizationPrompt",
      );
    }
    return {
      language: normalizedNextLanguage,
      prompt: drafts[normalizedNextLanguage],
    };
  }

  async function copyPromptValue(clipboard, value) {
    await clipboard.writeText(value);
  }

  function getSafeLocalStorage(root) {
    try {
      return root.localStorage;
    } catch (_error) {
      return null;
    }
  }

  function initialize(root = globalThis) {
    const doc = root.document;
    const settingsApi = root.YTD_SETTINGS;
    if (!doc || !settingsApi) return;

    const storage = createStorageAdapter(
      root.chrome,
      getSafeLocalStorage(root),
    );
    const form = doc.getElementById("settingsForm");
    const aiApiKeyInput = doc.getElementById("aiApiKey");
    const supadataApiKeyInput = doc.getElementById("supadataApiKey");
    const transcriptModeSelect = doc.getElementById("transcriptModeSelect");
    const overlayStyleSelect = doc.getElementById("overlayStyleSelect");
    const subtitleSyncOffsetInput = doc.getElementById("subtitleSyncOffset");
    const customizationPrompt = doc.getElementById("customizationPrompt");
    const copyCustomizationPromptBtn = doc.getElementById(
      "copyCustomizationPromptBtn",
    );
    const copyStatus = doc.getElementById("copyStatus");
    const saveStatus = doc.getElementById("saveStatus");
    const dataStatus = doc.getElementById("dataStatus");
    const languageButtons = [...doc.querySelectorAll("[data-language]")];
    const statusStates = new Map();
    const promptDrafts = createPromptDrafts();
    let currentLanguage = "en";

    function renderStatus(element) {
      const state = statusStates.get(element);
      element.textContent = state
        ? translate(currentLanguage, state.key, state.params)
        : "";
    }

    function setStatus(element, key, params = {}) {
      statusStates.set(element, { key, params });
      renderStatus(element);
    }

    function applyLanguage(language) {
      const nextDraft = switchPromptDraft(
        promptDrafts,
        currentLanguage,
        language,
        customizationPrompt.value,
      );
      currentLanguage = nextDraft.language;
      doc.documentElement.lang = currentLanguage;
      doc.title = translate(currentLanguage, "pageTitle");

      for (const element of doc.querySelectorAll("[data-i18n]")) {
        element.textContent = translate(
          currentLanguage,
          element.dataset.i18n,
        );
      }
      for (const element of doc.querySelectorAll("[data-i18n-html]")) {
        element.innerHTML = translate(
          currentLanguage,
          element.dataset.i18nHtml,
        );
      }
      for (const element of doc.querySelectorAll("[data-i18n-aria-label]")) {
        element.setAttribute(
          "aria-label",
          translate(currentLanguage, element.dataset.i18nAriaLabel),
        );
      }

      updateLocalizedPrompt(
        customizationPrompt,
        nextDraft.prompt,
      );
      updateLanguageButtonState(languageButtons, currentLanguage);
      for (const element of statusStates.keys()) renderStatus(element);
    }

    async function loadSettings() {
      try {
        const stored = await storage.get(settingsApi.STORAGE_KEY);
        const migration = settingsApi.migrateLegacyCustom(
          stored[settingsApi.STORAGE_KEY],
        );
        const settings = migration.settings;

        aiApiKeyInput.value = settings.aiApiKey;
        supadataApiKeyInput.value = settings.supadataApiKey;
        if (transcriptModeSelect) {
          transcriptModeSelect.value = settings.transcriptMode;
        }
        if (overlayStyleSelect) {
          overlayStyleSelect.value = settings.overlayStyle;
        }
        if (subtitleSyncOffsetInput) {
          subtitleSyncOffsetInput.value = settings.subtitleSyncOffset;
        }
        if (migration.migrated) {
          await storage.set({ [settingsApi.STORAGE_KEY]: settings });
          setStatus(saveStatus, "migrationWarning");
        }
      } catch (_error) {
        setStatus(saveStatus, "settingsLoadFailed");
      }
    }

    async function loadOptions() {
      try {
        applyLanguage(await readPreferredLanguage(storage));
      } catch (_error) {
        applyLanguage("en");
      }
      await loadSettings();
    }

    async function saveSettings(event) {
      event.preventDefault();
      setStatus(saveStatus, "saving");

      const settings = settingsApi.normalize({
        aiApiKey: aiApiKeyInput.value,
        supadataApiKey: supadataApiKeyInput.value,
        transcriptMode: transcriptModeSelect?.value,
        overlayStyle: overlayStyleSelect?.value,
        subtitleSyncOffset: Number(subtitleSyncOffsetInput?.value) || 0,
      });

      if (!settings.supadataApiKey) {
        setStatus(saveStatus, "addSupadataKey");
        return;
      }
      if (!settings.aiApiKey) {
        setStatus(saveStatus, "addDeepseekKey");
        return;
      }

      try {
        await storage.set({ [settingsApi.STORAGE_KEY]: settings });
        root.chrome?.runtime?.sendMessage?.({
          action: "overlayStyleChanged",
        })?.catch?.(() => {});
        setStatus(saveStatus, "saved");
      } catch (_error) {
        setStatus(saveStatus, "saveFailed");
      }
    }

    async function copyCustomizationPrompt() {
      setStatus(copyStatus, "copying");
      try {
        await copyPromptValue(
          root.navigator.clipboard,
          customizationPrompt.value,
        );
        setStatus(copyStatus, "promptCopied");
      } catch (_error) {
        setStatus(copyStatus, "copyFailed");
      }
    }

    async function clearCachedDigests() {
      const all = await storage.get(null);
      const keys = Object.keys(all).filter((key) => key.startsWith("digest_"));
      if (keys.length) await storage.remove(keys);
      setStatus(dataStatus, "clearedDigests", { count: keys.length });
    }

    async function clearNotes() {
      await storage.remove("ytd_notes");
      setStatus(dataStatus, "notesDeleted");
    }

    async function resetAllData() {
      const confirmed = root.confirm(
        translate(currentLanguage, "resetConfirm"),
      );
      if (!confirmed) return;

      await storage.clear();
      await persistPreferredLanguage(storage, currentLanguage);
      await loadSettings();
      setStatus(dataStatus, "allDataDeleted");
    }

    form.addEventListener("submit", saveSettings);
    copyCustomizationPromptBtn.addEventListener(
      "click",
      copyCustomizationPrompt,
    );
    doc
      .getElementById("clearCacheBtn")
      .addEventListener("click", clearCachedDigests);
    doc.getElementById("clearNotesBtn").addEventListener("click", clearNotes);
    doc.getElementById("resetBtn").addEventListener("click", resetAllData);
    for (const button of languageButtons) {
      button.addEventListener("click", async () => {
        const language = button.dataset.language;
        applyLanguage(language);
        await persistPreferredLanguage(storage, language);
      });
    }

    if (doc.readyState === "loading") {
      doc.addEventListener("DOMContentLoaded", loadOptions, { once: true });
    } else {
      void loadOptions();
    }
  }

  return {
    COPY,
    LANGUAGE_STORAGE_KEY,
    copyPromptValue,
    createPromptDrafts,
    createStorageAdapter,
    normalizeLanguage,
    persistPreferredLanguage,
    readPreferredLanguage,
    translate,
    updateLanguageButtonState,
    updateLocalizedPrompt,
    switchPromptDraft,
    initialize,
  };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = YTD_OPTIONS;
}

if (typeof document !== "undefined") {
  YTD_OPTIONS.initialize();
}
